import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getPrayerTimes } from "./services/prayerTimes";
import { getQuranSurahs, getQuranSurah } from "./services/quran";
import { getMorningAdhkar, getEveningAdhkar, getAllAdhkar } from "./services/adhkar";
import { queryAssistant } from "./services/assistant";

export async function registerRoutes(app: Express): Promise<Server> {
  // Prayer times endpoints
  app.get("/api/prayer-times", async (req, res) => {
    try {
      const { latitude, longitude, date, method } = req.query;
      
      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude are required" });
      }
      
      const data = await getPrayerTimes(
        parseFloat(latitude as string), 
        parseFloat(longitude as string),
        date as string,
        method as string
      );
      
      res.json(data);
    } catch (error) {
      console.error("Error fetching prayer times:", error);
      res.status(500).json({ message: "Failed to fetch prayer times" });
    }
  });

  // Quran endpoints
  app.get("/api/quran/surahs", async (_req, res) => {
    try {
      const data = await getQuranSurahs();
      res.json(data);
    } catch (error) {
      console.error("Error fetching Quran surahs:", error);
      res.status(500).json({ message: "Failed to fetch Quran surahs" });
    }
  });

  app.get("/api/quran/surah/:surahId", async (req, res) => {
    try {
      const { surahId } = req.params;
      const data = await getQuranSurah(parseInt(surahId));
      res.json(data);
    } catch (error) {
      console.error(`Error fetching Quran surah ${req.params.surahId}:`, error);
      res.status(500).json({ message: "Failed to fetch Quran surah" });
    }
  });

  // Adhkar endpoints
  app.get("/api/adhkar", async (_req, res) => {
    try {
      const data = await getAllAdhkar();
      res.json(data);
    } catch (error) {
      console.error("Error fetching adhkar:", error);
      res.status(500).json({ message: "Failed to fetch adhkar" });
    }
  });

  app.get("/api/adhkar/morning", async (_req, res) => {
    try {
      const data = await getMorningAdhkar();
      res.json(data);
    } catch (error) {
      console.error("Error fetching morning adhkar:", error);
      res.status(500).json({ message: "Failed to fetch morning adhkar" });
    }
  });

  app.get("/api/adhkar/evening", async (_req, res) => {
    try {
      const data = await getEveningAdhkar();
      res.json(data);
    } catch (error) {
      console.error("Error fetching evening adhkar:", error);
      res.status(500).json({ message: "Failed to fetch evening adhkar" });
    }
  });

  // Islamic Assistant endpoint
  app.post("/api/assistant/query", async (req, res) => {
    try {
      const { query } = req.body;
      
      if (!query) {
        return res.status(400).json({ message: "Query is required" });
      }
      
      const answer = await queryAssistant(query);
      res.json({ answer });
    } catch (error) {
      console.error("Error querying assistant:", error);
      res.status(500).json({ message: "Failed to get response from assistant" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
