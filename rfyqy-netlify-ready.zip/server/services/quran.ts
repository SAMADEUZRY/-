import https from "https";
import { Surah, surahs } from "@/data/quran";

interface QuranAPIResponse {
  code: number;
  status: string;
  data: {
    surahs: Surah[];
  };
}

interface SurahAPIResponse {
  code: number;
  status: string;
  data: {
    ayahs: {
      number: number;
      text: string;
      numberInSurah: number;
      juz: number;
      page: number;
    }[];
    edition: {
      identifier: string;
      language: string;
      name: string;
      englishName: string;
      format: string;
      type: string;
    };
    surah: Surah;
  };
}

/**
 * Get all Quran surahs
 * @returns Promise with all surahs
 */
export async function getQuranSurahs(): Promise<Surah[]> {
  // For this demo, we'll use the static data
  // In a real app, we would fetch from an API
  return Promise.resolve(surahs);

  // Example of how to fetch from API:
  /*
  return new Promise((resolve, reject) => {
    const url = "https://api.alquran.cloud/v1/surah";

    https
      .get(url, (res) => {
        let data = "";

        res.on("data", (chunk) => {
          data += chunk;
        });

        res.on("end", () => {
          try {
            const parsedData = JSON.parse(data) as QuranAPIResponse;
            if (parsedData.code === 200 && parsedData.status === "OK") {
              resolve(parsedData.data.surahs);
            } else {
              reject(new Error(`API returned error: ${parsedData.status}`));
            }
          } catch (error) {
            reject(error);
          }
        });
      })
      .on("error", (error) => {
        reject(error);
      });
  });
  */
}

/**
 * Get a specific surah by ID
 * @param surahId The ID of the surah to fetch
 * @returns Promise with the surah data
 */
export async function getQuranSurah(surahId: number): Promise<Surah> {
  // For this demo, we'll use the static data
  const surah = surahs.find(s => s.id === surahId);
  if (surah) {
    return Promise.resolve(surah);
  }
  return Promise.reject(new Error(`Surah ${surahId} not found`));

  // Example of how to fetch from API:
  /*
  return new Promise((resolve, reject) => {
    const url = `https://api.alquran.cloud/v1/surah/${surahId}`;

    https
      .get(url, (res) => {
        let data = "";

        res.on("data", (chunk) => {
          data += chunk;
        });

        res.on("end", () => {
          try {
            const parsedData = JSON.parse(data) as SurahAPIResponse;
            if (parsedData.code === 200 && parsedData.status === "OK") {
              resolve(parsedData.data.surah);
            } else {
              reject(new Error(`API returned error: ${parsedData.status}`));
            }
          } catch (error) {
            reject(error);
          }
        });
      })
      .on("error", (error) => {
        reject(error);
      });
  });
  */
}
