import { islamicQA } from './islamicData';

/**
 * Enhanced Islamic assistant that responds to religious questions
 * Uses an expanded database of QA pairs and keyword matching
 * @param query The question to answer
 * @returns Promise with the answer
 */
export async function queryAssistant(query: string): Promise<string> {
  // First check the existing keyword-based responses
  const existingResponses: Record<string, string> = {
    "أركان الإسلام": `أركان الإسلام خمسة:
1. شهادة أن لا إله إلا الله وأن محمداً رسول الله
2. إقام الصلاة
3. إيتاء الزكاة
4. صوم رمضان
5. حج البيت لمن استطاع إليه سبيلا`,

    "صلاة الضحى": `صلاة الضحى من السنن المؤكدة، وفضائلها كثيرة منها:
• تعادل صدقة على كل مفصل من مفاصل الإنسان
• سبب لمغفرة الذنوب
• عوناً للعبد في يومه
• وقتها: بعد ارتفاع الشمس قيد رمح (15-20 دقيقة بعد شروق الشمس) إلى قبيل الزوال
• عدد ركعاتها: أقلها ركعتان وأكثرها ثماني ركعات`,

    "الخشوع في الصلاة": `لتحقيق الخشوع في الصلاة:
• استحضر عظمة الله وأنك واقف بين يديه
• تدبر معاني الآيات والأذكار
• ابتعد عن المشتتات قبل وأثناء الصلاة
• حاول التركيز على أفعال الصلاة وعدم الاستعجال
• اختر مكاناً هادئاً للصلاة
• اجعل نظرك إلى موضع السجود
• تذكر أن هذه قد تكون آخر صلاة تصليها`,

    "آداب تلاوة القرآن": `من آداب تلاوة القرآن الكريم:
• الطهارة قبل قراءة القرآن
• استقبال القبلة إن أمكن
• الاستعاذة بالله من الشيطان الرجيم
• البسملة في بداية كل سورة إلا براءة (التوبة)
• القراءة بتدبر ومعرفة معاني الآيات
• الترتيل وتحسين الصوت
• السجود عند المرور بآيات السجدة
• الاستماع والإنصات عند قراءة القرآن`
  };

  // Check for exact keyword matches first
  for (const [keyword, response] of Object.entries(existingResponses)) {
    if (query.includes(keyword)) {
      return response;
    }
  }
  
  // Then search through the expanded QA database
  const bestMatch = findBestMatch(query);
  if (bestMatch) {
    return bestMatch.answer;
  }

  // Default response if no matches found
  return `شكراً لسؤالك عن "${query}". 

أنصحك بالرجوع إلى المصادر الإسلامية الموثوقة مثل القرآن الكريم والسنة النبوية الشريفة، أو استشارة عالم دين موثوق للحصول على إجابة دقيقة.

يمكنك أيضاً البحث في المواقع الإسلامية المعتمدة مثل موقع دار الإفتاء المصرية أو موقع إسلام ويب للحصول على فتاوى موثقة.`;
}

/**
 * Finds the best matching question from the Islamic QA database
 * @param query The user's query
 * @returns The best matching QA pair or null if no match is found
 */
function findBestMatch(query: string) {
  const normalizedQuery = normalizeText(query);
  let bestMatch = null;
  let highestScore = 0;

  // Search through all QA pairs
  for (const qa of islamicQA) {
    const score = calculateMatchScore(normalizedQuery, normalizeText(qa.question));
    
    if (score > highestScore && score > 0.35) { // Threshold for matching
      highestScore = score;
      bestMatch = qa;
    }
  }

  return bestMatch;
}

/**
 * Calculates a similarity score between the query and a potential match
 * @param query The normalized user query
 * @param target The normalized target question
 * @returns A score between 0 and 1, where 1 is a perfect match
 */
function calculateMatchScore(query: string, target: string): number {
  // If the query is contained in the target, it's a strong match
  if (target.includes(query)) {
    return 0.8 + (query.length / target.length) * 0.2; // Bonus for longer matches
  }
  
  // If target is contained in the query, it's also a good match
  if (query.includes(target)) {
    return 0.7 + (target.length / query.length) * 0.3;
  }
  
  // Check for keyword matches
  const queryWords = query.split(' ');
  const targetWords = target.split(' ');
  
  let matchingWords = 0;
  for (const qWord of queryWords) {
    if (qWord.length <= 2) continue; // Skip very short words
    
    for (const tWord of targetWords) {
      if (tWord.length <= 2) continue;
      
      if (tWord.includes(qWord) || qWord.includes(tWord)) {
        matchingWords++;
        break;
      }
    }
  }
  
  const score = matchingWords / Math.max(queryWords.length, 3);
  return score;
}

/**
 * Normalizes text for better matching
 * @param text Text to normalize
 * @returns Normalized text
 */
function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/ة/g, 'ه')
    .replace(/أ|إ|آ/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/؟/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}
