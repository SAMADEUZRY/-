import { allAdhkar, morningAdhkar, eveningAdhkar } from "@/data/adhkar";

type Dhikr = {
  id: number;
  text: string;
  transliteration?: string;
  translation?: string;
  source?: string;
  repeat: number;
  current: number;
  category: "morning" | "evening" | "both";
};

/**
 * Get all adhkar with current count initialized to 0
 * @returns Promise with all adhkar
 */
export async function getAllAdhkar(): Promise<Dhikr[]> {
  return Promise.resolve(
    allAdhkar.map(adhkar => ({
      ...adhkar,
      current: 0
    }))
  );
}

/**
 * Get morning adhkar with current count initialized to 0
 * @returns Promise with morning adhkar
 */
export async function getMorningAdhkar(): Promise<Dhikr[]> {
  return Promise.resolve(
    morningAdhkar.map(adhkar => ({
      ...adhkar,
      current: 0
    }))
  );
}

/**
 * Get evening adhkar with current count initialized to 0
 * @returns Promise with evening adhkar
 */
export async function getEveningAdhkar(): Promise<Dhikr[]> {
  return Promise.resolve(
    eveningAdhkar.map(adhkar => ({
      ...adhkar,
      current: 0
    }))
  );
}
