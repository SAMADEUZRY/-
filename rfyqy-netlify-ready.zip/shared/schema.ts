import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  email: text("email"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
});

// Prayer Times Preferences
export const prayerPreferences = pgTable("prayer_preferences", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  calculation_method: integer("calculation_method").default(2),
  notifications_enabled: boolean("notifications_enabled").default(true),
  asr_juristic: integer("asr_juristic").default(0),
  adjust_high_latitudes: integer("adjust_high_latitudes").default(0),
  time_format: integer("time_format").default(0),
});

export const insertPrayerPreferencesSchema = createInsertSchema(prayerPreferences).pick({
  user_id: true,
  calculation_method: true,
  notifications_enabled: true,
  asr_juristic: true,
  adjust_high_latitudes: true,
  time_format: true,
});

// Adhkar Tracking
export const adhkarTracking = pgTable("adhkar_tracking", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  adhkar_id: integer("adhkar_id").notNull(),
  completed_count: integer("completed_count").default(0),
  date: timestamp("date").defaultNow().notNull(),
  category: text("category").notNull(), // morning, evening, etc.
});

export const insertAdhkarTrackingSchema = createInsertSchema(adhkarTracking).pick({
  user_id: true,
  adhkar_id: true,
  completed_count: true,
  date: true,
  category: true,
});

// Quran Bookmarks
export const quranBookmarks = pgTable("quran_bookmarks", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  surah_id: integer("surah_id").notNull(),
  ayah_number: integer("ayah_number").notNull(),
  juz_number: integer("juz_number"),
  date_added: timestamp("date_added").defaultNow().notNull(),
  is_favorite: boolean("is_favorite").default(false),
  notes: text("notes"),
});

export const insertQuranBookmarkSchema = createInsertSchema(quranBookmarks).pick({
  user_id: true,
  surah_id: true,
  ayah_number: true,
  juz_number: true,
  is_favorite: true,
  notes: true,
});

// Tasbeeh History
export const tasbeehHistory = pgTable("tasbeeh_history", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  text: text("text").notNull(),
  count: integer("count").notNull(),
  date: timestamp("date").defaultNow().notNull(),
});

export const insertTasbeehHistorySchema = createInsertSchema(tasbeehHistory).pick({
  user_id: true,
  text: true,
  count: true,
  date: true,
});

// Assistant Queries
export const assistantQueries = pgTable("assistant_queries", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id),
  query: text("query").notNull(),
  response: text("response").notNull(),
  date: timestamp("date").defaultNow().notNull(),
});

export const insertAssistantQuerySchema = createInsertSchema(assistantQueries).pick({
  user_id: true,
  query: true,
  response: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertPrayerPreferences = z.infer<typeof insertPrayerPreferencesSchema>;
export type PrayerPreferences = typeof prayerPreferences.$inferSelect;

export type InsertAdhkarTracking = z.infer<typeof insertAdhkarTrackingSchema>;
export type AdhkarTracking = typeof adhkarTracking.$inferSelect;

export type InsertQuranBookmark = z.infer<typeof insertQuranBookmarkSchema>;
export type QuranBookmark = typeof quranBookmarks.$inferSelect;

export type InsertTasbeehHistory = z.infer<typeof insertTasbeehHistorySchema>;
export type TasbeehHistory = typeof tasbeehHistory.$inferSelect;

export type InsertAssistantQuery = z.infer<typeof insertAssistantQuerySchema>;
export type AssistantQuery = typeof assistantQueries.$inferSelect;
