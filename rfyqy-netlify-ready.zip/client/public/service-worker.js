
self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open("rafiqy-cache").then((cache) => {
      return cache.addAll(["/", "/index.html"]);
    })
  );
});

self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});
