import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

type MapLocation = {
  id: string;
  name: string;
  description: string;
  coordinates: {
    x: number;
    y: number;
  };
  category: string;
};

type MapCategory = {
  id: string;
  name: string;
  color: string;
};

// Locations in Masjid Al-Haram (Makkah)
const MAKKAH_LOCATIONS: MapLocation[] = [
  {
    id: "kaaba",
    name: "الكعبة المشرفة",
    description: "بيت الله الحرام، أول بيت وضع للناس في مكة، وقبلة المسلمين في صلاتهم",
    coordinates: { x: 50, y: 48 },
    category: "main"
  },
  {
    id: "black_stone",
    name: "الحجر الأسود",
    description: "حجر مقدس من الجنة، وضعه النبي إبراهيم وابنه إسماعيل عليهما السلام في الركن الشرقي من الكعبة",
    coordinates: { x: 57, y: 48 },
    category: "main"
  },
  {
    id: "maqam_ibrahim",
    name: "مقام إبراهيم",
    description: "الحجر الذي وقف عليه إبراهيم عليه السلام أثناء بناء الكعبة، وفيه أثر قدميه",
    coordinates: { x: 55, y: 55 },
    category: "main"
  },
  {
    id: "zamzam_well",
    name: "بئر زمزم",
    description: "البئر المقدس الذي فجره الله لهاجر وابنها إسماعيل، ماؤه شفاء لما شرب له",
    coordinates: { x: 58, y: 45 },
    category: "main"
  },
  {
    id: "safa",
    name: "الصفا",
    description: "أحد جبلين بين الصفا والمروة يتم السعي بينهما، وهو نقطة بداية السعي",
    coordinates: { x: 70, y: 48 },
    category: "masaa"
  },
  {
    id: "marwa",
    name: "المروة",
    description: "الجبل الآخر في السعي، وهو نقطة نهاية السعي",
    coordinates: { x: 30, y: 48 },
    category: "masaa"
  },
  {
    id: "hijr_ismail",
    name: "حجر إسماعيل",
    description: "المنطقة المحاطة بجدار قصير على شكل نصف دائرة قرب الكعبة، وهو جزء من الكعبة الأصلية",
    coordinates: { x: 45, y: 42 },
    category: "main"
  },
  {
    id: "mizab",
    name: "ميزاب الرحمة",
    description: "مجرى الماء الموجود في سطح الكعبة لتصريف مياه الأمطار",
    coordinates: { x: 45, y: 39 },
    category: "main"
  },
  {
    id: "king_fahd_gate",
    name: "باب الملك فهد",
    description: "أحد أبواب المسجد الحرام الرئيسية",
    coordinates: { x: 85, y: 48 },
    category: "gate"
  },
  {
    id: "king_abdullah_gate",
    name: "باب الملك عبدالله",
    description: "باب رئيسي من أبواب المسجد الحرام",
    coordinates: { x: 15, y: 48 },
    category: "gate"
  },
  {
    id: "mataf",
    name: "المطاف",
    description: "المنطقة المحيطة بالكعبة المشرفة حيث يؤدي المسلمون طواف القدوم والإفاضة والوداع",
    coordinates: { x: 50, y: 48 },
    category: "area"
  },
  {
    id: "masaa",
    name: "المسعى",
    description: "المنطقة بين الصفا والمروة حيث يؤدي المسلمون شعيرة السعي",
    coordinates: { x: 50, y: 48 },
    category: "area"
  }
];

// Locations in Masjid Al-Nabawi (Madinah)
const MADINAH_LOCATIONS: MapLocation[] = [
  {
    id: "rawdah",
    name: "الروضة الشريفة",
    description: "المنطقة بين منبر النبي وبيته، وهي روضة من رياض الجنة",
    coordinates: { x: 50, y: 40 },
    category: "main"
  },
  {
    id: "prophets_grave",
    name: "قبر النبي ﷺ",
    description: "قبر النبي محمد ﷺ وصاحبيه أبي بكر وعمر رضي الله عنهما",
    coordinates: { x: 55, y: 40 },
    category: "main"
  },
  {
    id: "prophets_mimbar",
    name: "منبر النبي ﷺ",
    description: "المنبر الذي كان يخطب عليه النبي ﷺ",
    coordinates: { x: 45, y: 40 },
    category: "main"
  },
  {
    id: "baqee_gate",
    name: "باب البقيع",
    description: "باب يؤدي إلى مقبرة البقيع، حيث دفن العديد من الصحابة رضي الله عنهم",
    coordinates: { x: 70, y: 40 },
    category: "gate"
  },
  {
    id: "baab_assalam",
    name: "باب السلام",
    description: "أحد أبواب المسجد النبوي الرئيسية، ويستحب الدخول منه",
    coordinates: { x: 30, y: 50 },
    category: "gate"
  },
  {
    id: "baab_gabriel",
    name: "باب جبريل",
    description: "باب سمي بهذا الاسم لأن جبريل عليه السلام كان يدخل منه لمقابلة النبي ﷺ",
    coordinates: { x: 25, y: 35 },
    category: "gate"
  },
  {
    id: "mehrab_othman",
    name: "محراب عثمان",
    description: "محراب قديم في المسجد النبوي نسبة إلى عثمان بن عفان رضي الله عنه",
    coordinates: { x: 55, y: 55 },
    category: "historical"
  },
  {
    id: "meehrab_tahajjud",
    name: "محراب التهجد",
    description: "محراب في موضع صلاة النبي ﷺ قيام الليل في بيته",
    coordinates: { x: 60, y: 45 },
    category: "historical"
  },
  {
    id: "suffah",
    name: "الصُفّة",
    description: "مكان في المسجد النبوي كان يأوي إليه فقراء المهاجرين الذين لا مأوى لهم",
    coordinates: { x: 45, y: 60 },
    category: "historical"
  }
];

// Map categories for legend
const MAP_CATEGORIES: MapCategory[] = [
  { id: "main", name: "معالم رئيسية", color: "#4CAF50" },
  { id: "masaa", name: "منطقة المسعى", color: "#2196F3" },
  { id: "gate", name: "أبواب", color: "#FFC107" },
  { id: "area", name: "مناطق عامة", color: "#9C27B0" },
  { id: "historical", name: "معالم تاريخية", color: "#795548" }
];

export default function InteractiveHaramMap() {
  const [activeMap, setActiveMap] = useState<"makkah" | "madinah">("makkah");
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showAllLabels, setShowAllLabels] = useState<boolean>(false);

  // Get current map locations based on active map
  const currentLocations = activeMap === "makkah" ? MAKKAH_LOCATIONS : MADINAH_LOCATIONS;
  
  // Get selected location details
  const locationDetails = selectedLocation 
    ? currentLocations.find(loc => loc.id === selectedLocation) 
    : null;

  // Filter locations by category if a category is selected
  const filteredLocations = selectedCategory 
    ? currentLocations.filter(loc => loc.category === selectedCategory)
    : currentLocations;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>خريطة الحرمين الشريفين التفاعلية</CardTitle>
          <CardDescription>
            استكشف معالم المسجد الحرام في مكة المكرمة والمسجد النبوي في المدينة المنورة
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <Tabs
            defaultValue="makkah"
            value={activeMap}
            onValueChange={(value) => {
              setActiveMap(value as "makkah" | "madinah");
              setSelectedLocation(null);
            }}
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="makkah">المسجد الحرام</TabsTrigger>
              <TabsTrigger value="madinah">المسجد النبوي</TabsTrigger>
            </TabsList>
            
            <div className="my-4 flex justify-between">
              <Select
                value={selectedCategory || ""}
                onValueChange={(value) => setSelectedCategory(value || null)}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="جميع المعالم" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">جميع المعالم</SelectItem>
                  {MAP_CATEGORIES.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <div className="flex items-center space-x-2 space-x-reverse">
                <label htmlFor="show-labels" className="text-sm">
                  إظهار جميع الأسماء
                </label>
                <input
                  type="checkbox"
                  id="show-labels"
                  checked={showAllLabels}
                  onChange={(e) => setShowAllLabels(e.target.checked)}
                  className="mr-2"
                />
              </div>
            </div>
            
            <TabsContent value="makkah" className="mt-4">
              <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden border">
                {/* This would be a real map in production */}
                <div className="absolute inset-0 bg-[url('/images/makkah-map-placeholder.jpg')] bg-cover bg-center opacity-50"></div>
                
                {/* Map overlay with markers */}
                <div className="absolute inset-0">
                  {filteredLocations.map((location) => (
                    <TooltipProvider key={location.id}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button
                            className={`absolute rounded-full ${
                              selectedLocation === location.id 
                                ? 'h-5 w-5 ring-4 ring-primary animate-pulse' 
                                : 'h-4 w-4'
                            }`}
                            style={{
                              top: `${location.coordinates.y}%`,
                              left: `${location.coordinates.x}%`,
                              backgroundColor: MAP_CATEGORIES.find(c => c.id === location.category)?.color || '#333',
                              transform: 'translate(-50%, -50%)'
                            }}
                            onClick={() => setSelectedLocation(location.id)}
                          ></button>
                        </TooltipTrigger>
                        <TooltipContent side="top">
                          {location.name}
                        </TooltipContent>
                      </Tooltip>
                      
                      {(showAllLabels || selectedLocation === location.id) && (
                        <div 
                          className="absolute text-xs font-bold bg-white/80 px-1 rounded shadow-sm"
                          style={{
                            top: `${location.coordinates.y + 3}%`,
                            left: `${location.coordinates.x}%`,
                            transform: 'translate(-50%, 0)'
                          }}
                        >
                          {location.name}
                        </div>
                      )}
                    </TooltipProvider>
                  ))}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="madinah" className="mt-4">
              <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden border">
                {/* This would be a real map in production */}
                <div className="absolute inset-0 bg-[url('/images/madinah-map-placeholder.jpg')] bg-cover bg-center opacity-50"></div>
                
                {/* Map overlay with markers */}
                <div className="absolute inset-0">
                  {filteredLocations.map((location) => (
                    <TooltipProvider key={location.id}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button
                            className={`absolute rounded-full ${
                              selectedLocation === location.id 
                                ? 'h-5 w-5 ring-4 ring-primary animate-pulse' 
                                : 'h-4 w-4'
                            }`}
                            style={{
                              top: `${location.coordinates.y}%`,
                              left: `${location.coordinates.x}%`,
                              backgroundColor: MAP_CATEGORIES.find(c => c.id === location.category)?.color || '#333',
                              transform: 'translate(-50%, -50%)'
                            }}
                            onClick={() => setSelectedLocation(location.id)}
                          ></button>
                        </TooltipTrigger>
                        <TooltipContent side="top">
                          {location.name}
                        </TooltipContent>
                      </Tooltip>
                      
                      {(showAllLabels || selectedLocation === location.id) && (
                        <div 
                          className="absolute text-xs font-bold bg-white/80 px-1 rounded shadow-sm"
                          style={{
                            top: `${location.coordinates.y + 3}%`,
                            left: `${location.coordinates.x}%`,
                            transform: 'translate(-50%, 0)'
                          }}
                        >
                          {location.name}
                        </div>
                      )}
                    </TooltipProvider>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          {/* Legend */}
          <div className="flex flex-wrap gap-3 mt-4 justify-center">
            {MAP_CATEGORIES.map((category) => (
              <div 
                key={category.id} 
                className="flex items-center gap-1 text-sm"
                onClick={() => setSelectedCategory(selectedCategory === category.id ? null : category.id)}
                style={{ cursor: 'pointer' }}
              >
                <div 
                  className={`h-3 w-3 rounded-full ${selectedCategory === category.id ? 'ring-2 ring-offset-1' : ''}`}
                  style={{ backgroundColor: category.color }}
                ></div>
                <span>{category.name}</span>
              </div>
            ))}
          </div>
          
          {/* Selected location info */}
          {locationDetails && (
            <div className="bg-muted p-4 rounded-lg mt-4">
              <h3 className="font-bold text-lg">{locationDetails.name}</h3>
              <p className="text-sm text-muted-foreground">{locationDetails.description}</p>
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex-col space-y-2">
          <p className="text-sm text-muted-foreground text-center">
            انقر على أي معلم في الخريطة للحصول على معلومات إضافية.
          </p>
          
          <div className="text-xs text-center">
            <p>استخدم هذه الخريطة التفاعلية للمساعدة في التعرف على أهم المعالم في الحرمين الشريفين.</p>
            <p className="text-primary">تذكر أن تزور هذه الأماكن بنية صالحة وخشوع.</p>
          </div>
        </CardFooter>
      </Card>
      
      {/* Historical information */}
      <Card>
        <CardHeader>
          <CardTitle>معلومات تاريخية</CardTitle>
          <CardDescription>
            نبذة عن تاريخ الحرمين الشريفين
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <Tabs defaultValue="makkah_history">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="makkah_history">المسجد الحرام</TabsTrigger>
              <TabsTrigger value="madinah_history">المسجد النبوي</TabsTrigger>
            </TabsList>
            
            <TabsContent value="makkah_history" className="mt-4 space-y-4">
              <div>
                <h3 className="font-bold">تاريخ بناء المسجد الحرام</h3>
                <p className="text-sm text-muted-foreground">
                  يُعتبر المسجد الحرام أقدم مسجد في الإسلام وأكبرها، وقد بدأ بناؤه على يد إبراهيم وإسماعيل عليهما السلام. ومر بمراحل توسعة عديدة عبر التاريخ الإسلامي، من العصر الأموي والعباسي، ثم العثماني، وصولاً إلى التوسعات السعودية الضخمة في العصر الحديث التي جعلته يستوعب أكثر من مليوني مصلٍ في وقت واحد.
                </p>
              </div>
              
              <div>
                <h3 className="font-bold">مكونات المسجد الحرام</h3>
                <ul className="list-disc list-inside text-sm text-muted-foreground mr-4 space-y-1">
                  <li>الكعبة المشرفة: أول بيت وضع للناس، وقبلة المسلمين في صلاتهم.</li>
                  <li>الحجر الأسود: حجر من الجنة أنزله الله إلى الأرض.</li>
                  <li>مقام إبراهيم: الحجر الذي وقف عليه إبراهيم عليه السلام عند بناء الكعبة.</li>
                  <li>حجر إسماعيل: الجزء الذي يقع بين الركنين الشمالي والغربي للكعبة.</li>
                  <li>بئر زمزم: البئر المقدس الذي فجره الله لهاجر وابنها إسماعيل.</li>
                  <li>المسعى: المنطقة المخصصة للسعي بين الصفا والمروة.</li>
                </ul>
              </div>
            </TabsContent>
            
            <TabsContent value="madinah_history" className="mt-4 space-y-4">
              <div>
                <h3 className="font-bold">تأسيس المسجد النبوي</h3>
                <p className="text-sm text-muted-foreground">
                  أسس المسجد النبوي الشريف النبي محمد ﷺ بعد هجرته من مكة إلى المدينة المنورة عام 622م. وكان المسجد في بدايته بسيطاً في بنائه، مبنياً من اللبن والطين وجذوع النخل. وقد توسع المسجد على مر العصور الإسلامية، من العصر الراشدي، والأموي، والعباسي، والعثماني، وصولاً إلى التوسعات السعودية الحديثة.
                </p>
              </div>
              
              <div>
                <h3 className="font-bold">معالم المسجد النبوي</h3>
                <ul className="list-disc list-inside text-sm text-muted-foreground mr-4 space-y-1">
                  <li>الروضة الشريفة: المنطقة بين منبر النبي ﷺ وبيته، وهي روضة من رياض الجنة.</li>
                  <li>الحجرة النبوية الشريفة: موضع قبر النبي ﷺ وصاحبيه أبي بكر وعمر رضي الله عنهما.</li>
                  <li>المنبر النبوي: المنبر الذي كان يخطب عليه النبي ﷺ.</li>
                  <li>الأساطين المميزة: مثل أسطوانة التوبة وأسطوانة الحرس وأسطوانة السرير وغيرها.</li>
                  <li>المحاريب: مثل المحراب النبوي والمحراب العثماني.</li>
                </ul>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      {/* Hajj and Umrah guide card */}
      <Card>
        <CardHeader>
          <CardTitle>دليل مناسك الحج والعمرة</CardTitle>
          <CardDescription>
            معلومات عملية لأداء مناسك الحج والعمرة
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <Tabs defaultValue="umrah">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="umrah">العمرة</TabsTrigger>
              <TabsTrigger value="hajj">الحج</TabsTrigger>
            </TabsList>
            
            <TabsContent value="umrah" className="mt-4">
              <h3 className="font-bold mb-2">خطوات أداء العمرة</h3>
              <ol className="list-decimal list-inside space-y-2 mr-4">
                <li className="text-sm">
                  <span className="font-bold">الإحرام:</span> الاغتسال ولبس ملابس الإحرام والنية والتلبية.
                </li>
                <li className="text-sm">
                  <span className="font-bold">الطواف:</span> الطواف حول الكعبة المشرفة سبعة أشواط، بداية من الحجر الأسود.
                </li>
                <li className="text-sm">
                  <span className="font-bold">صلاة ركعتين:</span> خلف مقام إبراهيم إن تيسر.
                </li>
                <li className="text-sm">
                  <span className="font-bold">شرب ماء زمزم:</span> الشرب من ماء زمزم والدعاء.
                </li>
                <li className="text-sm">
                  <span className="font-bold">السعي:</span> السعي بين الصفا والمروة سبعة أشواط.
                </li>
                <li className="text-sm">
                  <span className="font-bold">الحلق أو التقصير:</span> حلق الشعر أو تقصيره للرجال، والتقصير للنساء.
                </li>
              </ol>
            </TabsContent>
            
            <TabsContent value="hajj" className="mt-4">
              <h3 className="font-bold mb-2">خطوات أداء الحج</h3>
              <ol className="list-decimal list-inside space-y-2 mr-4">
                <li className="text-sm">
                  <span className="font-bold">الإحرام:</span> الاغتسال ولبس ملابس الإحرام والنية والتلبية (8 ذو الحجة).
                </li>
                <li className="text-sm">
                  <span className="font-bold">الوقوف بعرفة:</span> الوقوف بجبل عرفات من ظهر يوم 9 ذو الحجة إلى غروب الشمس.
                </li>
                <li className="text-sm">
                  <span className="font-bold">المبيت بمزدلفة:</span> المبيت في مزدلفة ليلة 10 ذو الحجة.
                </li>
                <li className="text-sm">
                  <span className="font-bold">رمي جمرة العقبة:</span> في يوم 10 ذو الحجة.
                </li>
                <li className="text-sm">
                  <span className="font-bold">النحر:</span> ذبح الهدي في يوم 10 ذو الحجة.
                </li>
                <li className="text-sm">
                  <span className="font-bold">الحلق أو التقصير:</span> حلق الشعر أو تقصيره.
                </li>
                <li className="text-sm">
                  <span className="font-bold">طواف الإفاضة:</span> الطواف حول الكعبة المشرفة سبعة أشواط.
                </li>
                <li className="text-sm">
                  <span className="font-bold">السعي:</span> السعي بين الصفا والمروة إن لم يكن قد سعى مع طواف القدوم.
                </li>
                <li className="text-sm">
                  <span className="font-bold">المبيت بمنى:</span> المبيت بمنى ليالي 11 و12 و13 ذو الحجة (أيام التشريق).
                </li>
                <li className="text-sm">
                  <span className="font-bold">رمي الجمرات:</span> رمي الجمرات الثلاث في أيام 11 و12 و13 ذو الحجة.
                </li>
                <li className="text-sm">
                  <span className="font-bold">طواف الوداع:</span> الطواف حول الكعبة المشرفة سبعة أشواط قبل مغادرة مكة.
                </li>
              </ol>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}