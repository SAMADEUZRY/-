import { useState, useRef, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Bot, Layers, User } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { ScrollArea } from "@/components/ui/scroll-area";

type Message = {
  id: string;
  text: string;
  sender: "user" | "assistant";
  timestamp: number;
};

export default function IslamicAssistant() {
  const { t } = useTranslation();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "initial",
      text: t("assistant.greeting"),
      sender: "assistant",
      timestamp: Date.now(),
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Suggested questions from the design
  const suggestedQuestions = [
    "ما هي أركان الإسلام؟",
    "كيف أخشع في الصلاة؟",
    "ما هي آداب تلاوة القرآن؟",
  ];

  // Scroll to bottom when messages change
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = async () => {
    if (!inputText.trim() || isProcessing) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      text: inputText,
      sender: "user",
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputText("");
    setIsProcessing(true);

    try {
      const response = await apiRequest("POST", "/api/assistant/query", {
        query: inputText,
      });
      
      const assistantResponse = await response.json();
      
      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        text: assistantResponse.answer,
        sender: "assistant",
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error getting response from assistant:", error);
      
      // Add error message
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        text: "عذراً، حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى.",
        sender: "assistant",
        timestamp: Date.now(),
      };
      
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  };

  const setQuestion = (question: string) => {
    setInputText(question);
  };

  return (
    <Card className="mt-4 overflow-hidden rounded-xl shadow-md mb-20">
      <CardHeader className="bg-primary text-white p-4">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Bot className="h-5 w-5" />
          {t("assistant.title")}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <p className="text-gray-700 mb-4">{t("assistant.description")}</p>
        
        {/* Chat Interface */}
        <ScrollArea ref={scrollAreaRef} className="border border-gray-200 rounded-lg mb-4 h-64 p-3 bg-gray-50">
          {messages.map((message) => (
            <div key={message.id} className={`flex mb-3 ${message.sender === "user" ? "justify-end" : ""}`}>
              {message.sender === "assistant" && (
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
                  <Bot size={16} />
                </div>
              )}
              
              <div className={`mx-2 ${message.sender === "assistant" ? "bg-primary-bg text-gray-700" : "bg-primary text-white"} rounded-lg p-2 max-w-[80%]`}>
                <p className="whitespace-pre-wrap">{message.text}</p>
              </div>
              
              {message.sender === "user" && (
                <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center">
                  <User size={16} />
                </div>
              )}
            </div>
          ))}
          
          {isProcessing && (
            <div className="flex mb-3">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
                <Bot size={16} />
              </div>
              <div className="mr-2 bg-primary-bg rounded-lg p-2">
                <p className="text-gray-700">جاري التفكير...</p>
              </div>
            </div>
          )}
        </ScrollArea>
        
        {/* Input Area */}
        <div className="flex gap-2">
          <Input
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={t("assistant.placeholder")}
            onKeyDown={handleKeyPress}
            className="flex-1"
            disabled={isProcessing}
          />
          <Button
            variant="default"
            className="bg-primary hover:bg-primary-dark"
            onClick={sendMessage}
            disabled={!inputText.trim() || isProcessing}
          >
            <Layers size={18} />
          </Button>
        </div>
        
        {/* Suggested Questions */}
        <div className="mt-4">
          <h3 className="font-medium text-primary mb-2">{t("assistant.suggestedQuestions")}</h3>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((question, index) => (
              <Button
                key={index}
                variant="outline"
                className="bg-primary-bg text-primary hover:bg-primary hover:text-white"
                onClick={() => setQuestion(question)}
              >
                {question}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
