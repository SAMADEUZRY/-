import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { HandHelping, Plus, RotateCcw, Save } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useLocalStorage } from "@/hooks/useLocalStorage";

export default function DigitalTasbeeh() {
  const { t } = useTranslation();
  const [count, setCount] = useLocalStorage("tasbeeh-count", 0);
  const [maxCount, setMaxCount] = useLocalStorage("tasbeeh-max", 99);
  const [text, setText] = useLocalStorage("tasbeeh-text", t("tasbeeh.subhanAllah"));
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    setProgress(Math.round((count / maxCount) * 100));
  }, [count, maxCount]);

  const incrementTasbeeh = () => {
    setCount(prev => (prev < maxCount ? prev + 1 : prev));
  };

  const resetTasbeeh = () => {
    setCount(0);
  };

  const saveTasbeeh = () => {
    // In a real app, we would save to history or database
    // For now, just show a browser alert
    alert(`تم حفظ ${count} ${text}`);
  };

  const handleTextChange = (newText: string) => {
    setText(newText);
    resetTasbeeh();
  };

  return (
    <Card className="mt-4 overflow-hidden rounded-xl shadow-md">
      <CardHeader className="bg-primary text-white p-4">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <HandHelping className="h-5 w-5" />
          {t("tasbeeh.title")}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 flex flex-col items-center">
        {/* Tasbeeh Counter Display */}
        <div className="w-48 h-48 rounded-full border-8 border-primary flex items-center justify-center mb-6 bg-primary-bg">
          <span className="text-4xl font-bold text-primary">{count}</span>
        </div>
        
        {/* Tasbeeh Control Buttons */}
        <div className="flex flex-wrap gap-3 w-full justify-center">
          <Button 
            variant="default" 
            className="tasbeeh-btn bg-primary hover:bg-primary-dark flex gap-2"
            onClick={incrementTasbeeh}
          >
            <Plus size={16} /> {text}
          </Button>
          
          <Button 
            variant="outline" 
            className="tasbeeh-btn text-gray-700 flex gap-2"
            onClick={resetTasbeeh}
          >
            <RotateCcw size={16} /> {t("tasbeeh.reset")}
          </Button>
          
          <Button 
            variant="default"
            className="tasbeeh-btn bg-primary-light hover:bg-primary flex gap-2"
            onClick={saveTasbeeh}
          >
            <Save size={16} /> {t("tasbeeh.save")}
          </Button>
        </div>
        
        {/* Tasbeeh Presets */}
        <div className="grid grid-cols-2 gap-3 w-full mt-4">
          <Button 
            variant="ghost" 
            className={`bg-primary-bg text-primary hover:bg-primary hover:text-white ${text === t("tasbeeh.subhanAllah") ? "bg-primary text-white" : ""}`}
            onClick={() => handleTextChange(t("tasbeeh.subhanAllah"))}
          >
            {t("tasbeeh.subhanAllah")}
          </Button>
          <Button 
            variant="ghost" 
            className={`bg-primary-bg text-primary hover:bg-primary hover:text-white ${text === t("tasbeeh.alhamdulillah") ? "bg-primary text-white" : ""}`}
            onClick={() => handleTextChange(t("tasbeeh.alhamdulillah"))}
          >
            {t("tasbeeh.alhamdulillah")}
          </Button>
          <Button 
            variant="ghost" 
            className={`bg-primary-bg text-primary hover:bg-primary hover:text-white ${text === t("tasbeeh.allahuAkbar") ? "bg-primary text-white" : ""}`}
            onClick={() => handleTextChange(t("tasbeeh.allahuAkbar"))}
          >
            {t("tasbeeh.allahuAkbar")}
          </Button>
          <Button 
            variant="ghost" 
            className={`bg-primary-bg text-primary hover:bg-primary hover:text-white ${text === t("tasbeeh.lailahaillallah") ? "bg-primary text-white" : ""}`}
            onClick={() => handleTextChange(t("tasbeeh.lailahaillallah"))}
          >
            {t("tasbeeh.lailahaillallah")}
          </Button>
        </div>
        
        {/* Tasbeeh Progress */}
        <Progress value={progress} className="w-full mt-4 bg-gray-200 h-2.5 rounded-full" />
        <p className="text-sm text-gray-600 text-center mt-1">
          {t("tasbeeh.completed", { completed: count, total: maxCount })}
        </p>
      </CardContent>
    </Card>
  );
}
