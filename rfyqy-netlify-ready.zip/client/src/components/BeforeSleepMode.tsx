import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLocalStorage } from "@/hooks/useLocalStorage";

type SleepModeSettings = {
  activeDuration: number; // in minutes
  background: string;
  content: string;
  volume: number;
  autoStop: boolean;
};

const DEFAULT_SETTINGS: SleepModeSettings = {
  activeDuration: 15,
  background: "stars",
  content: "mulk",
  volume: 70,
  autoStop: true,
};

const BACKGROUNDS = [
  { id: "stars", name: "سماء مرصعة بالنجوم" },
  { id: "mosque", name: "منظر المسجد ليلاً" },
  { id: "moon", name: "ضوء القمر" },
  { id: "forest", name: "غابة هادئة" },
  { id: "rain", name: "مطر خفيف" },
];

const CONTENT_OPTIONS = [
  { id: "mulk", name: "سورة الملك", source: "sheikh1" },
  { id: "sajda", name: "سورة السجدة", source: "sheikh1" },
  { id: "yaseen", name: "سورة يس", source: "sheikh2" },
  { id: "rahman", name: "سورة الرحمن", source: "sheikh2" },
  { id: "adhkar", name: "أذكار النوم", source: "sheikh3" },
];

export default function BeforeSleepMode() {
  const [settings, setSettings] = useLocalStorage<SleepModeSettings>(
    "before_sleep_settings",
    DEFAULT_SETTINGS
  );
  const [isActive, setIsActive] = useState(false);
  const [remainingTime, setRemainingTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<number | null>(null);

  // Update settings
  const updateSettings = (newSettings: Partial<SleepModeSettings>) => {
    setSettings({
      ...settings,
      ...newSettings,
    });
  };

  // Start sleep mode
  const startSleepMode = () => {
    setIsActive(true);
    setIsPlaying(true);
    setRemainingTime(settings.activeDuration * 60); // Convert minutes to seconds
    
    // Start countdown timer
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
    }
    
    timerRef.current = window.setInterval(() => {
      setRemainingTime((prevTime) => {
        if (prevTime <= 1) {
          if (settings.autoStop) {
            stopSleepMode();
          }
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);
  };

  // Stop sleep mode
  const stopSleepMode = () => {
    setIsActive(false);
    setIsPlaying(false);
    
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  // Toggle play/pause
  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  // Format time display (MM:SS)
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Effect to handle audio playback
  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(error => {
          console.error("Error playing audio:", error);
          setIsPlaying(false);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying]);

  // Effect to update audio volume
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = settings.volume / 100;
    }
  }, [settings.volume]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
      }
    };
  }, []);

  return (
    <div className="space-y-4 p-4">
      <h2 className="text-2xl font-bold text-center">وضع ما قبل النوم</h2>

      {isActive ? (
        <div className="relative">
          {/* Visualization background */}
          <div 
            className="absolute inset-0 rounded-lg overflow-hidden z-0 opacity-80"
            style={{
              backgroundImage: `url(backgrounds/${settings.background}.jpg)`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
          
          {/* Content overlay */}
          <Card className="relative z-10 bg-opacity-70 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-2xl">
                {CONTENT_OPTIONS.find(c => c.id === settings.content)?.name || "تلاوة قرآنية"}
              </CardTitle>
              <CardDescription>
                استمع وتأمل مع الاسترخاء للاستعداد للنوم
              </CardDescription>
            </CardHeader>
            
            <CardContent className="flex flex-col items-center justify-center space-y-8 p-8">
              {/* Timer display */}
              <div className="text-3xl font-mono font-bold py-2 px-6 rounded-full bg-background/30 backdrop-blur-md">
                {formatTime(remainingTime)}
              </div>
              
              {/* Audio element (hidden) */}
              <audio 
                ref={audioRef}
                src={`/audio/${settings.content}.mp3`}
                loop={!settings.autoStop}
                style={{ display: 'none' }}
              />
              
              {/* Playback controls */}
              <div className="flex space-x-4 space-x-reverse">
                <Button
                  size="icon"
                  variant="outline"
                  className="rounded-full w-14 h-14 bg-background/50 backdrop-blur-sm"
                  onClick={togglePlayPause}
                >
                  <i className={`fas fa-${isPlaying ? 'pause' : 'play'} text-xl`}></i>
                </Button>
                
                <Button
                  size="icon"
                  variant="outline"
                  className="rounded-full w-14 h-14 bg-background/50 backdrop-blur-sm"
                  onClick={stopSleepMode}
                >
                  <i className="fas fa-stop text-xl"></i>
                </Button>
              </div>
              
              {/* Volume slider */}
              <div className="flex items-center space-x-4 space-x-reverse w-full max-w-xs">
                <i className="fas fa-volume-down text-lg"></i>
                <Slider
                  value={[settings.volume]}
                  min={0}
                  max={100}
                  step={5}
                  onValueChange={(values) => updateSettings({ volume: values[0] })}
                  className="flex-1"
                  dir="ltr"
                />
                <i className="fas fa-volume-up text-lg"></i>
              </div>
            </CardContent>
            
            <CardFooter>
              <p className="text-sm text-center w-full text-muted-foreground">
                أغمض عينيك، وتنفس بعمق، ودع الأفكار تمر دون التمسك بها
              </p>
            </CardFooter>
          </Card>
        </div>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>إعدادات وضع ما قبل النوم</CardTitle>
            <CardDescription>
              بيئة هادئة للاستماع إلى تلاوة القرآن أو الأذكار قبل النوم
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium">المحتوى</label>
              <Select
                value={settings.content}
                onValueChange={(value) => updateSettings({ content: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CONTENT_OPTIONS.map((option) => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">الخلفية المرئية</label>
              <Select
                value={settings.background}
                onValueChange={(value) => updateSettings({ background: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {BACKGROUNDS.map((bg) => (
                    <SelectItem key={bg.id} value={bg.id}>
                      {bg.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm font-medium">مدة التشغيل (بالدقائق)</label>
                <span className="text-sm font-medium">{settings.activeDuration} دقيقة</span>
              </div>
              <Slider
                value={[settings.activeDuration]}
                min={5}
                max={60}
                step={5}
                onValueChange={(values) =>
                  updateSettings({ activeDuration: values[0] })
                }
                dir="ltr"
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm font-medium">مستوى الصوت</label>
                <span className="text-sm font-medium">{settings.volume}%</span>
              </div>
              <Slider
                value={[settings.volume]}
                min={0}
                max={100}
                step={5}
                onValueChange={(values) =>
                  updateSettings({ volume: values[0] })
                }
                dir="ltr"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">إيقاف تلقائي بعد انتهاء المدة</label>
              <Switch
                checked={settings.autoStop}
                onCheckedChange={(checked) =>
                  updateSettings({ autoStop: checked })
                }
              />
            </div>
          </CardContent>
          
          <CardFooter>
            <Button
              className="w-full"
              onClick={startSleepMode}
            >
              <i className="fas fa-moon ml-2"></i>
              بدء وضع الاسترخاء قبل النوم
            </Button>
          </CardFooter>
        </Card>
      )}
      
      <div className="mt-6">
        <h3 className="text-xl font-semibold mb-3">فوائد التهيئة للنوم</h3>
        <ul className="space-y-2 list-disc list-inside text-muted-foreground">
          <li>تلاوة سورة الملك تحمي من عذاب القبر</li>
          <li>أذكار النوم تحافظ عليك من الشيطان وسوء الأحلام</li>
          <li>يساعد على الاسترخاء والنوم بشكل أفضل</li>
          <li>ينهي يومك بذكر الله والقرآن</li>
          <li>يجعل القراءة والاستماع للقرآن عادة يومية</li>
        </ul>
      </div>
    </div>
  );
}