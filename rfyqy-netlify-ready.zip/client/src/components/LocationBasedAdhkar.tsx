import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useLocalStorage } from "@/hooks/useLocalStorage";

// Define location types
type LocationType = "mosque" | "home" | "market" | "travel" | "unknown";

// Define adhkar for different locations
type LocationAdhkar = {
  id: number;
  text: string;
  translation?: string;
  location: LocationType;
};

const LOCATION_ADHKAR: LocationAdhkar[] = [
  {
    id: 1,
    text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلِجِ وَخَيْرَ الْمَخْرَجِ، بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا",
    translation: "O Allah, I ask You for the goodness of the entrance and the goodness of the exit. In the name of Allah we enter, in the name of Allah we leave, and upon Allah, our Lord, we rely",
    location: "home"
  },
  {
    id: 2,
    text: "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
    translation: "In the name of Allah, I have placed my trust in Allah; there is no power and no strength except with Allah",
    location: "travel"
  },
  {
    id: 3,
    text: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ أَنْ أَضِلَّ أَوْ أُضَلَّ، أَوْ أَزِلَّ أَوْ أُزَلَّ، أَوْ أَظْلِمَ أَوْ أُظْلَمَ، أَوْ أَجْهَلَ أَوْ يُجْهَلَ عَلَيَّ",
    translation: "O Allah, I seek refuge in You lest I should stray or be led astray, or slip or be tripped, or oppress or be oppressed, or behave foolishly or be treated foolishly",
    location: "travel"
  },
  {
    id: 4,
    text: "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ",
    translation: "O Allah, open for me the gates of Your mercy",
    location: "mosque"
  },
  {
    id: 5,
    text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ",
    translation: "O Allah, I ask You for Your bounty",
    location: "mosque"
  },
  {
    id: 6,
    text: "اللَّهُمَّ إنِّي أَعُوذُ بِكَ مِنَ الْخُبْثِ وَالْخَبَائِثِ",
    translation: "O Allah, I seek refuge in You from the male and female devils",
    location: "home"
  },
  {
    id: 7,
    text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ هَذَا السُّوقِ وَخَيْرَ مَا فِيهِ، وَأَعُوذُ بِكَ مِنْ شَرِّهِ وَشَرِّ مَا فِيهِ، اللَّهُمَّ إِنِّي أَعُوذُ بِكَ أَنْ أُصِيبَ فِيهِ يَمِينًا فَاجِرَةً، أَوْ صَفْقَةً خَاسِرَةً",
    translation: "O Allah, I ask You for the goodness of this market and the goodness of what is in it, and I seek refuge in You from its evil and the evil of what is in it. O Allah, I seek refuge in You from taking a false oath in it, or from a losing deal",
    location: "market"
  }
];

// Location detection mockup
const detectLocation = (): Promise<LocationType> => {
  return new Promise((resolve) => {
    // In a real app, this would use geofencing, GPS and nearby places API
    // For demonstration, we'll randomly simulate different locations
    const locations: LocationType[] = ["mosque", "home", "market", "travel"];
    const randomLocation = locations[Math.floor(Math.random() * locations.length)];
    
    setTimeout(() => {
      resolve(randomLocation);
    }, 1000);
  });
};

export default function LocationBasedAdhkar() {
  const [currentLocation, setCurrentLocation] = useState<LocationType>("unknown");
  const [detecting, setDetecting] = useState(false);
  const [relevantAdhkar, setRelevantAdhkar] = useState<LocationAdhkar[]>([]);
  const [savedLocations, setSavedLocations] = useLocalStorage<Record<string, LocationType>>("saved_locations", {});
  
  const { coords } = useGeolocation();
  const { toast } = useToast();

  const locationNames = {
    mosque: "المسجد",
    home: "المنزل",
    market: "السوق",
    travel: "السفر",
    unknown: "غير معروف"
  };

  // Manually set location for testing purposes
  const setManualLocation = (location: LocationType) => {
    setCurrentLocation(location);
    const filteredAdhkar = LOCATION_ADHKAR.filter(dhikr => dhikr.location === location);
    setRelevantAdhkar(filteredAdhkar);
    
    toast({
      title: `تم تحديد الموقع: ${locationNames[location]}`,
      description: `تم إظهار الأذكار المناسبة لهذا المكان`,
    });
  };

  // Detect location automatically
  const detectCurrentLocation = async () => {
    if (!coords) {
      toast({
        title: "خطأ في تحديد الموقع",
        description: "يرجى السماح بتحديد موقعك للاستفادة من هذه الميزة",
        variant: "destructive",
      });
      return;
    }

    setDetecting(true);
    try {
      // In a real app, you would use the coords to determine location type
      const detectedLocation = await detectLocation();
      setCurrentLocation(detectedLocation);
      
      // Filter adhkar based on detected location
      const filteredAdhkar = LOCATION_ADHKAR.filter(dhikr => dhikr.location === detectedLocation);
      setRelevantAdhkar(filteredAdhkar);
      
      toast({
        title: `تم تحديد موقعك: ${locationNames[detectedLocation]}`,
        description: "تم إظهار الأذكار المناسبة لهذا المكان",
      });
    } catch (error) {
      toast({
        title: "خطأ في تحديد الموقع",
        description: "حدث خطأ أثناء محاولة تحديد موقعك الحالي",
        variant: "destructive",
      });
    } finally {
      setDetecting(false);
    }
  };

  // Save current location
  const saveCurrentLocation = () => {
    if (currentLocation === "unknown" || !coords) return;
    
    // In a real app, this would save the GPS coordinates associated with the location type
    const locationKey = `${coords.latitude},${coords.longitude}`;
    setSavedLocations({
      ...savedLocations,
      [locationKey]: currentLocation
    });
    
    toast({
      title: "تم حفظ الموقع",
      description: `تم حفظ موقعك الحالي كـ "${locationNames[currentLocation]}"`,
    });
  };

  return (
    <div className="space-y-4 p-4">
      <h2 className="text-2xl font-bold text-center">أذكار حسب المكان</h2>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>موقعك الحالي: {locationNames[currentLocation]}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setManualLocation("mosque")}
              className={currentLocation === "mosque" ? "border-primary" : ""}
            >
              <i className="fas fa-mosque ml-2"></i>
              المسجد
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setManualLocation("home")}
              className={currentLocation === "home" ? "border-primary" : ""}
            >
              <i className="fas fa-home ml-2"></i>
              المنزل
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setManualLocation("market")}
              className={currentLocation === "market" ? "border-primary" : ""}
            >
              <i className="fas fa-shopping-cart ml-2"></i>
              السوق
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setManualLocation("travel")}
              className={currentLocation === "travel" ? "border-primary" : ""}
            >
              <i className="fas fa-car ml-2"></i>
              السفر
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Button 
              className="flex-1"
              onClick={detectCurrentLocation}
              disabled={detecting}
            >
              {detecting ? (
                <>
                  <i className="fas fa-spinner fa-spin ml-2"></i>
                  جاري التحديد...
                </>
              ) : (
                <>
                  <i className="fas fa-location-arrow ml-2"></i>
                  تحديد تلقائي
                </>
              )}
            </Button>
            
            <Button 
              variant="outline"
              onClick={saveCurrentLocation}
              disabled={currentLocation === "unknown" || !coords}
            >
              <i className="fas fa-save ml-2"></i>
              حفظ الموقع
            </Button>
          </div>
        </CardContent>
      </Card>

      {relevantAdhkar.length > 0 ? (
        <div className="space-y-4">
          <h3 className="text-xl font-semibold">الأذكار المناسبة لموقعك</h3>
          
          {relevantAdhkar.map((dhikr) => (
            <Card key={dhikr.id} className="overflow-hidden">
              <CardContent className="p-4">
                <p className="text-lg font-medium mb-2 text-right font-arabic leading-loose">
                  {dhikr.text}
                </p>
                {dhikr.translation && (
                  <p className="text-sm text-muted-foreground">
                    {dhikr.translation}
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : currentLocation !== "unknown" ? (
        <div className="text-center py-6 text-muted-foreground">
          لا توجد أذكار محددة لهذا المكان حالياً
        </div>
      ) : null}
    </div>
  );
}