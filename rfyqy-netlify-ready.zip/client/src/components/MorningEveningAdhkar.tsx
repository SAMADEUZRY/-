import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Sun, ChevronDown, Minus, Plus, RotateCcw } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useQuery } from "@tanstack/react-query";
import { Separator } from "@/components/ui/separator";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

type Dhikr = {
  id: number;
  text: string;
  transliteration?: string;
  translation?: string;
  source?: string;
  repeat: number;
  current: number;
  category: "morning" | "evening" | "both";
};

export default function MorningEveningAdhkar() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useLocalStorage("adhkar-active-tab", "morning");
  const [notificationsEnabled, setNotificationsEnabled] = useLocalStorage("adhkar-notifications", true);
  const [adhkarProgress, setAdhkarProgress] = useState<number>(0);
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({});

  const { data: adhkar, isLoading, error } = useQuery({
    queryKey: ["/api/adhkar"],
  });

  const toggleDhikr = (id: number) => {
    setOpenItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const incrementDhikr = (dhikr: Dhikr) => {
    if (dhikr.current < dhikr.repeat) {
      const updatedAdhkar = adhkar.map((d: Dhikr) => 
        d.id === dhikr.id ? { ...d, current: d.current + 1 } : d
      );
      
      // In a real app, we would update the server
      // For demonstration, we're just updating the local state
      updateAdhkarProgress(updatedAdhkar);
    }
  };

  const decrementDhikr = (dhikr: Dhikr) => {
    if (dhikr.current > 0) {
      const updatedAdhkar = adhkar.map((d: Dhikr) => 
        d.id === dhikr.id ? { ...d, current: d.current - 1 } : d
      );
      
      updateAdhkarProgress(updatedAdhkar);
    }
  };

  const resetDhikr = (dhikr: Dhikr) => {
    const updatedAdhkar = adhkar.map((d: Dhikr) => 
      d.id === dhikr.id ? { ...d, current: 0 } : d
    );
    
    updateAdhkarProgress(updatedAdhkar);
  };

  const updateAdhkarProgress = (updatedAdhkar: Dhikr[]) => {
    const filtered = updatedAdhkar.filter((d: Dhikr) => 
      d.category === activeTab || d.category === "both"
    );
    
    const totalRepeats = filtered.reduce((sum, d) => sum + d.repeat, 0);
    const completedRepeats = filtered.reduce((sum, d) => sum + d.current, 0);
    
    const progress = totalRepeats > 0 ? Math.round((completedRepeats / totalRepeats) * 100) : 0;
    setAdhkarProgress(progress);
  };

  useEffect(() => {
    if (adhkar) {
      updateAdhkarProgress(adhkar);
    }
  }, [adhkar, activeTab]);

  const toggleNotifications = () => {
    if (!notificationsEnabled) {
      // Request notification permission
      Notification.requestPermission().then(permission => {
        if (permission === "granted") {
          setNotificationsEnabled(true);
          new Notification("أذكار", {
            body: "تم تفعيل التنبيهات للأذكار"
          });
        } else {
          alert("يرجى السماح بالإشعارات لتلقي تنبيهات الأذكار");
        }
      });
    } else {
      setNotificationsEnabled(false);
    }
  };

  // Filter adhkar based on active tab
  const filteredAdhkar = adhkar?.filter((d: Dhikr) => 
    d.category === activeTab || d.category === "both"
  ) || [];

  return (
    <Card className="mt-4 overflow-hidden rounded-xl shadow-md">
      <CardHeader className="bg-primary text-white p-4">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Sun className="h-5 w-5" />
          {t("adhkar.title")}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        {/* Morning/Evening Toggle */}
        <div className="flex rounded-lg mb-4 bg-gray-100 p-1">
          <Button 
            variant={activeTab === "morning" ? "default" : "ghost"}
            className={`flex-1 py-2 rounded-lg font-medium ${activeTab === "morning" ? "bg-primary text-white" : "text-gray-700"}`}
            onClick={() => setActiveTab("morning")}
          >
            {t("adhkar.morning")}
          </Button>
          <Button 
            variant={activeTab === "evening" ? "default" : "ghost"}
            className={`flex-1 py-2 rounded-lg font-medium ${activeTab === "evening" ? "bg-primary text-white" : "text-gray-700"}`}
            onClick={() => setActiveTab("evening")}
          >
            {t("adhkar.evening")}
          </Button>
        </div>
        
        {/* Adhkar Images */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <img 
            src="https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300" 
            alt="منظر شروق الشمس" 
            className={`rounded-lg shadow-md w-full h-auto ${activeTab === "evening" ? "hidden md:block" : ""}`}
          />
          <img 
            src="https://pixabay.com/get/gf1e37736ca8dda950a72f1f3ac85c998f739e6104759fa99eca44256f5cf58b4f7dfa86811b7a1832b57a2d08611ee53369d87a4d560dc674e7113029e4b20d2_1280.jpg" 
            alt="مسبحة وقت الغروب" 
            className={`rounded-lg shadow-md w-full h-auto ${activeTab === "morning" ? "hidden md:block" : ""}`}
          />
        </div>
        
        {isLoading ? (
          <div className="text-center py-8">{t("general.loading")}</div>
        ) : error ? (
          <div className="text-center py-4 text-red-500">{t("general.error")}</div>
        ) : (
          /* Adhkar List */
          <div className="space-y-3">
            {filteredAdhkar.map((dhikr: Dhikr) => (
              <Collapsible 
                key={dhikr.id}
                open={openItems[dhikr.id]}
                onOpenChange={() => toggleDhikr(dhikr.id)}
                className="border border-gray-200 rounded-lg overflow-hidden"
              >
                <CollapsibleTrigger className="p-3 bg-primary-bg flex justify-between items-center cursor-pointer w-full">
                  <div className="font-medium text-start">{dhikr.text.length > 60 ? dhikr.text.substring(0, 60) + "..." : dhikr.text}</div>
                  <div className="flex items-center gap-2">
                    <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">
                      {dhikr.current}/{dhikr.repeat}
                    </span>
                    <ChevronDown className="h-4 w-4 text-primary transition-transform duration-200" />
                  </div>
                </CollapsibleTrigger>
                
                <CollapsibleContent className="p-3 border-t border-gray-200 bg-white">
                  <p className="text-gray-700 mb-2">{dhikr.text}</p>
                  {dhikr.translation && <p className="text-sm text-gray-500 mb-1">{dhikr.translation}</p>}
                  {dhikr.source && <p className="text-sm text-gray-600 mb-3">{dhikr.source}</p>}
                  
                  <Separator className="my-2" />
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="outline" 
                        size="icon" 
                        className="w-8 h-8 rounded-full bg-primary-bg text-primary"
                        onClick={() => decrementDhikr(dhikr)}
                        disabled={dhikr.current <= 0}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span className="font-medium">{dhikr.current}</span>
                      <Button 
                        variant="outline" 
                        size="icon" 
                        className="w-8 h-8 rounded-full bg-primary-bg text-primary"
                        onClick={() => incrementDhikr(dhikr)}
                        disabled={dhikr.current >= dhikr.repeat}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <Button 
                      variant="default" 
                      size="sm" 
                      className="bg-primary-light hover:bg-primary"
                      onClick={() => resetDhikr(dhikr)}
                    >
                      <RotateCcw className="h-4 w-4 mr-1" /> {t("tasbeeh.reset")}
                    </Button>
                  </div>
                </CollapsibleContent>
              </Collapsible>
            ))}
          </div>
        )}
        
        {/* Adhkar Progress */}
        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-1">
            <span>{t("adhkar.progress", { time: activeTab === "morning" ? t("adhkar.morning") : t("adhkar.evening") })}</span>
            <span>{adhkarProgress}%</span>
          </div>
          <Progress value={adhkarProgress} className="w-full h-2.5" />
        </div>
        
        {/* Smart Notifications Toggle */}
        <div className="flex justify-between items-center mt-4 p-3 bg-gray-100 rounded-lg">
          <div>
            <p className="font-medium">{t("adhkar.enableNotifications")}</p>
            <p className="text-sm text-gray-600">{t("adhkar.notificationsDesc")}</p>
          </div>
          <Switch
            checked={notificationsEnabled}
            onCheckedChange={toggleNotifications}
          />
        </div>
      </CardContent>
    </Card>
  );
}
