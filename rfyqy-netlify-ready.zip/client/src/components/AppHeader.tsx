import { useTranslation } from "react-i18next";
import { Bell, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AppHeader() {
  const { t } = useTranslation();

  return (
    <header className="bg-gradient-to-l from-primary-dark to-primary sticky top-0 z-10 shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <h1 className="text-white text-2xl font-bold">{t("appName")}</h1>
        <div className="flex items-center space-x-2 space-x-reverse">
          <Button variant="ghost" size="icon" className="text-white hover:bg-primary-dark/50 rounded-full">
            <Bell size={20} />
          </Button>
          <Button variant="ghost" size="icon" className="text-white hover:bg-primary-dark/50 rounded-full">
            <Settings size={20} />
          </Button>
        </div>
      </div>
    </header>
  );
}
