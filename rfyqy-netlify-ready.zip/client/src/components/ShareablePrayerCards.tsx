import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

type CardTemplate = {
  id: string;
  name: string;
  backgroundImage: string;
  colors: {
    primary: string;
    secondary: string;
    text: string;
  };
  direction: "rtl" | "ltr";
};

type SuggestedDua = {
  id: string;
  category: string;
  text: string;
  for?: string;
};

const CARD_TEMPLATES: CardTemplate[] = [
  {
    id: "mosque-sunset",
    name: "مسجد عند الغروب",
    backgroundImage: "mosque-sunset.jpg",
    colors: {
      primary: "#2A3990",
      secondary: "#F9B384",
      text: "#FFFFFF",
    },
    direction: "rtl",
  },
  {
    id: "kaaba",
    name: "الكعبة المشرفة",
    backgroundImage: "kaaba.jpg",
    colors: {
      primary: "#000000",
      secondary: "#D4AF37",
      text: "#FFFFFF",
    },
    direction: "rtl",
  },
  {
    id: "blue-mosque",
    name: "المسجد الأزرق",
    backgroundImage: "blue-mosque.jpg",
    colors: {
      primary: "#0F4C81",
      secondary: "#E8F1F5",
      text: "#FFFFFF",
    },
    direction: "rtl",
  },
  {
    id: "desert-sunset",
    name: "غروب الصحراء",
    backgroundImage: "desert-sunset.jpg",
    colors: {
      primary: "#E17055",
      secondary: "#FAD02C",
      text: "#FFFFFF",
    },
    direction: "rtl",
  },
  {
    id: "stars",
    name: "سماء مليئة بالنجوم",
    backgroundImage: "stars.jpg",
    colors: {
      primary: "#1B262C",
      secondary: "#BBE1FA",
      text: "#FFFFFF",
    },
    direction: "rtl",
  },
];

const SUGGESTED_DUAS: SuggestedDua[] = [
  {
    id: "parents",
    category: "الوالدين",
    text: "رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا",
    for: "للوالدين",
  },
  {
    id: "forgiveness",
    category: "المغفرة",
    text: "رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ",
    for: "للمغفرة",
  },
  {
    id: "sick",
    category: "المرضى",
    text: "اللَّهُمَّ رَبَّ النَّاسِ، أَذْهِبِ الْبَاسَ، اشْفِ أَنْتَ الشَّافِي، لَا شِفَاءَ إِلَّا شِفَاؤُكَ، شِفَاءً لَا يُغَادِرُ سَقَمًا",
    for: "للمريض",
  },
  {
    id: "rizq",
    category: "الرزق",
    text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا",
    for: "للرزق",
  },
  {
    id: "protection",
    category: "الحماية",
    text: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
    for: "للحماية",
  },
  {
    id: "success",
    category: "النجاح",
    text: "رَبِّ اشْرَحْ لِي صَدْرِي، وَيَسِّرْ لِي أَمْرِي",
    for: "للنجاح",
  },
  {
    id: "happiness",
    category: "السعادة",
    text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْهُدَى، وَالتُّقَى، وَالْعَفَافَ، وَالْغِنَى",
    for: "للسعادة",
  },
];

export default function ShareablePrayerCards() {
  const [selectedTemplate, setSelectedTemplate] = useState<string>(CARD_TEMPLATES[0].id);
  const [selectedDua, setSelectedDua] = useState<string>("");
  const [customDuaText, setCustomDuaText] = useState<string>("");
  const [customDuaFor, setCustomDuaFor] = useState<string>("");
  const [activeTab, setActiveTab] = useState<string>("suggested");
  const cardRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const template = CARD_TEMPLATES.find((t) => t.id === selectedTemplate);
  const dua = SUGGESTED_DUAS.find((d) => d.id === selectedDua);

  const duaText = activeTab === "suggested" ? dua?.text || "" : customDuaText;
  const duaFor = activeTab === "suggested" ? dua?.for || "" : customDuaFor;

  const handleShare = () => {
    if (!duaText) {
      toast({
        title: "الدعاء فارغ",
        description: "يرجى كتابة أو اختيار دعاء قبل المشاركة",
        variant: "destructive",
      });
      return;
    }

    // In a real app, this would use html2canvas or a similar library to create an image
    // For this demonstration, we'll just show a success message
    toast({
      title: "تم إنشاء البطاقة",
      description: "تم إنشاء بطاقة الدعاء بنجاح، يمكنك مشاركتها الآن",
    });

    // Simulate share dialog
    setTimeout(() => {
      if (navigator.share) {
        navigator
          .share({
            title: "بطاقة دعاء",
            text: `${duaText} - ${duaFor}`,
            // url: "URL to the image would go here in a real app"
          })
          .catch((error) => console.log("Error sharing:", error));
      } else {
        toast({
          title: "المشاركة غير متاحة",
          description: "ميزة المشاركة غير متوفرة في متصفحك",
          variant: "destructive",
        });
      }
    }, 1000);
  };

  const handleSaveImage = () => {
    if (!duaText) {
      toast({
        title: "الدعاء فارغ",
        description: "يرجى كتابة أو اختيار دعاء قبل الحفظ",
        variant: "destructive",
      });
      return;
    }

    // In a real app, this would use html2canvas to download the image
    toast({
      title: "تم حفظ البطاقة",
      description: "تم حفظ بطاقة الدعاء كصورة على جهازك",
    });
  };

  return (
    <div className="space-y-4 p-4">
      <h2 className="text-2xl font-bold text-center">بطاقات الدعاء القابلة للمشاركة</h2>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="suggested">أدعية مقترحة</TabsTrigger>
          <TabsTrigger value="custom">دعاء مخصص</TabsTrigger>
        </TabsList>

        <TabsContent value="suggested" className="space-y-4 pt-2">
          <div className="space-y-2">
            <label className="text-sm font-medium">اختر دعاءً</label>
            <Select
              value={selectedDua}
              onValueChange={setSelectedDua}
            >
              <SelectTrigger>
                <SelectValue placeholder="اختر دعاءً من القائمة" />
              </SelectTrigger>
              <SelectContent>
                {SUGGESTED_DUAS.map((dua) => (
                  <SelectItem key={dua.id} value={dua.id}>
                    {dua.for}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedDua && (
            <Card className="bg-muted">
              <CardContent className="p-4">
                <p className="text-lg font-arabic text-center">{dua?.text}</p>
                <p className="text-sm text-muted-foreground text-center mt-2">{dua?.for}</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="custom" className="space-y-4 pt-2">
          <div className="space-y-2">
            <label className="text-sm font-medium">نص الدعاء</label>
            <Textarea
              placeholder="اكتب دعاءً مخصصاً..."
              value={customDuaText}
              onChange={(e) => setCustomDuaText(e.target.value)}
              className="min-h-[100px] font-arabic"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">لمن الدعاء؟</label>
            <Input
              placeholder="مثال: لأمي الغالية، لصديق مريض..."
              value={customDuaFor}
              onChange={(e) => setCustomDuaFor(e.target.value)}
            />
          </div>
        </TabsContent>
      </Tabs>

      <div className="space-y-2 pt-4">
        <label className="text-sm font-medium">اختر تصميم البطاقة</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 overflow-x-auto pb-2">
          {CARD_TEMPLATES.map((template) => (
            <div
              key={template.id}
              className={`relative overflow-hidden rounded-lg h-24 cursor-pointer border-2 ${
                selectedTemplate === template.id
                  ? "border-primary"
                  : "border-transparent"
              }`}
              onClick={() => setSelectedTemplate(template.id)}
              style={{
                backgroundImage: `url(/backgrounds/${template.backgroundImage})`,
                backgroundSize: "cover",
                backgroundPosition: "center",
              }}
            >
              <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                <span className="text-white text-sm font-medium">{template.name}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Preview card */}
      {template && (
        <div className="pt-6">
          <h3 className="text-lg font-semibold mb-4">معاينة البطاقة</h3>
          
          <div 
            ref={cardRef}
            className="relative overflow-hidden rounded-lg aspect-[3/4] max-w-xs mx-auto shadow-lg"
            style={{
              backgroundImage: `url(/backgrounds/${template.backgroundImage})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              direction: template.direction,
            }}
          >
            {/* Overlay for better text readability */}
            <div className="absolute inset-0 bg-black bg-opacity-30"></div>
            
            {/* Content */}
            <div className="relative z-10 h-full flex flex-col items-center justify-center p-6 text-center">
              {duaText ? (
                <>
                  <p 
                    className="text-xl font-arabic leading-relaxed"
                    style={{ color: template.colors.text }}
                  >
                    {duaText}
                  </p>
                  
                  {duaFor && (
                    <div 
                      className="mt-auto pt-4 font-semibold px-4 py-2 rounded-full text-sm"
                      style={{ 
                        backgroundColor: template.colors.primary,
                        color: template.colors.text
                      }}
                    >
                      {duaFor}
                    </div>
                  )}
                </>
              ) : (
                <p className="text-white text-opacity-70 text-center">
                  اختر أو اكتب دعاءً للمعاينة
                </p>
              )}
            </div>
          </div>

          <div className="flex justify-center gap-4 mt-6">
            <Button
              onClick={handleSaveImage}
              variant="outline"
              disabled={!duaText}
            >
              <i className="fas fa-download ml-2"></i>
              حفظ كصورة
            </Button>
            
            <Button
              onClick={handleShare}
              disabled={!duaText}
            >
              <i className="fas fa-share-alt ml-2"></i>
              مشاركة
            </Button>
          </div>
        </div>
      )}
      
      <div className="mt-6 text-center text-sm text-muted-foreground">
        شارك دعاءك مع العائلة والأصدقاء، لكل مشاركة أجر كبير.
      </div>
    </div>
  );
}