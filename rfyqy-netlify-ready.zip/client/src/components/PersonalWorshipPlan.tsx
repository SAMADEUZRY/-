import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "@/hooks/use-toast";

type Goal = {
  id: string;
  type: string;
  target: number;
  current: number;
  timeframe: "daily" | "weekly" | "monthly";
  description: string;
  createdAt: string;
};

type GoalType = {
  id: string;
  name: string;
  description: string;
  options: {
    timeframes: Array<"daily" | "weekly" | "monthly">;
    targets: number[];
  };
};

const GOAL_TYPES: GoalType[] = [
  {
    id: "quran_khatm",
    name: "ختم القرآن",
    description: "قراءة القرآن الكريم كاملاً",
    options: {
      timeframes: ["daily", "weekly", "monthly"],
      targets: [1, 2, 3, 5, 10, 30],
    },
  },
  {
    id: "quran_hifz",
    name: "حفظ القرآن",
    description: "حفظ سورة أو جزء من القرآن",
    options: {
      timeframes: ["daily", "weekly", "monthly"],
      targets: [1, 3, 5, 10, 15, 30],
    },
  },
  {
    id: "night_prayer",
    name: "قيام الليل",
    description: "الاستيقاظ لصلاة التهجد",
    options: {
      timeframes: ["daily", "weekly", "monthly"],
      targets: [1, 2, 3, 5, 7, 15, 30],
    },
  },
  {
    id: "adhkar_morning",
    name: "أذكار الصباح",
    description: "المداومة على أذكار الصباح",
    options: {
      timeframes: ["daily", "weekly", "monthly"],
      targets: [1, 3, 5, 7, 15, 30],
    },
  },
  {
    id: "adhkar_evening",
    name: "أذكار المساء",
    description: "المداومة على أذكار المساء",
    options: {
      timeframes: ["daily", "weekly", "monthly"],
      targets: [1, 3, 5, 7, 15, 30],
    },
  },
  {
    id: "voluntary_fasting",
    name: "صيام النوافل",
    description: "صيام الاثنين والخميس أو أيام البيض",
    options: {
      timeframes: ["weekly", "monthly"],
      targets: [1, 2, 3, 4, 8, 12],
    },
  },
];

const timeframeLabels = {
  daily: "يومي",
  weekly: "أسبوعي",
  monthly: "شهري",
};

export default function PersonalWorshipPlan() {
  const [goals, setGoals] = useLocalStorage<Goal[]>("worship_goals", []);
  const [selectedGoalType, setSelectedGoalType] = useState<string>("");
  const [selectedTimeframe, setSelectedTimeframe] = useState<"daily" | "weekly" | "monthly">("daily");
  const [selectedTarget, setSelectedTarget] = useState<number>(1);
  const { toast } = useToast();

  const selectedGoalTypeObj = GOAL_TYPES.find((g) => g.id === selectedGoalType);

  const handleCreateGoal = () => {
    if (!selectedGoalType || !selectedTimeframe || !selectedTarget) {
      toast({
        title: "خطأ",
        description: "الرجاء تعبئة جميع الحقول",
        variant: "destructive",
      });
      return;
    }

    const goalType = GOAL_TYPES.find((gt) => gt.id === selectedGoalType);
    if (!goalType) return;

    const newGoal: Goal = {
      id: crypto.randomUUID(),
      type: selectedGoalType,
      target: selectedTarget,
      current: 0,
      timeframe: selectedTimeframe,
      description: goalType.description,
      createdAt: new Date().toISOString(),
    };

    setGoals([...goals, newGoal]);
    toast({
      title: "تم إنشاء الهدف",
      description: `تم إضافة ${goalType.name} إلى خطتك`,
    });

    setSelectedGoalType("");
    setSelectedTimeframe("daily");
    setSelectedTarget(1);
  };

  const updateGoalProgress = (goalId: string, increment: boolean) => {
    setGoals(
      goals.map((goal) => {
        if (goal.id === goalId) {
          const newCurrent = increment
            ? Math.min(goal.current + 1, goal.target)
            : Math.max(goal.current - 1, 0);
          return { ...goal, current: newCurrent };
        }
        return goal;
      })
    );
  };

  const deleteGoal = (goalId: string) => {
    setGoals(goals.filter((goal) => goal.id !== goalId));
    toast({
      title: "تم حذف الهدف",
      description: "تم حذف الهدف من خطتك",
    });
  };

  return (
    <div className="space-y-4 p-4">
      <h2 className="text-2xl font-bold text-center">خطة العبادة الشخصية</h2>
      <Card>
        <CardHeader>
          <CardTitle>إنشاء هدف جديد</CardTitle>
          <CardDescription>اختر نوع العبادة والهدف المراد تحقيقه</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">نوع العبادة</label>
              <Select
                value={selectedGoalType}
                onValueChange={(value) => {
                  setSelectedGoalType(value);
                  const goalType = GOAL_TYPES.find((gt) => gt.id === value);
                  if (goalType) {
                    setSelectedTimeframe(goalType.options.timeframes[0]);
                  }
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر نوع العبادة" />
                </SelectTrigger>
                <SelectContent>
                  {GOAL_TYPES.map((goalType) => (
                    <SelectItem key={goalType.id} value={goalType.id}>
                      {goalType.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedGoalTypeObj && (
              <>
                <div className="space-y-2">
                  <label className="text-sm font-medium">الإطار الزمني</label>
                  <Select
                    value={selectedTimeframe}
                    onValueChange={(value) => setSelectedTimeframe(value as "daily" | "weekly" | "monthly")}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedGoalTypeObj.options.timeframes.map((timeframe) => (
                        <SelectItem key={timeframe} value={timeframe}>
                          {timeframeLabels[timeframe]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">الهدف</label>
                  <Select
                    value={selectedTarget.toString()}
                    onValueChange={(value) => setSelectedTarget(parseInt(value))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedGoalTypeObj.options.targets.map((target) => (
                        <SelectItem key={target} value={target.toString()}>
                          {target} {selectedTimeframe === "daily" ? "مرة في اليوم" : selectedTimeframe === "weekly" ? "مرة في الأسبوع" : "مرة في الشهر"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" onClick={handleCreateGoal}>
            إضافة الهدف
          </Button>
        </CardFooter>
      </Card>

      <h3 className="text-xl font-semibold mt-6 mb-4">أهدافك الحالية</h3>

      {goals.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          لم تقم بإضافة أهداف بعد. أضف هدفًا جديدًا لتتبع تقدمك.
        </div>
      ) : (
        <div className="space-y-4">
          {goals.map((goal) => {
            const goalType = GOAL_TYPES.find((gt) => gt.id === goal.type);
            const progress = Math.round((goal.current / goal.target) * 100);

            return (
              <Card key={goal.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">{goalType?.name}</CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteGoal(goal.id)}
                      className="h-8 w-8 p-0 text-destructive"
                    >
                      <span className="sr-only">حذف</span>
                      <i className="fas fa-trash-alt"></i>
                    </Button>
                  </div>
                  <CardDescription>
                    {goal.timeframe === "daily"
                      ? "هدف يومي"
                      : goal.timeframe === "weekly"
                      ? "هدف أسبوعي"
                      : "هدف شهري"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>التقدم: {goal.current} من {goal.target}</span>
                      <span className="text-sm text-muted-foreground">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                </CardContent>
                <CardFooter className="pt-2">
                  <div className="flex justify-between w-full">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateGoalProgress(goal.id, false)}
                      disabled={goal.current <= 0}
                    >
                      <i className="fas fa-minus mr-1"></i>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateGoalProgress(goal.id, true)}
                      disabled={goal.current >= goal.target}
                    >
                      <i className="fas fa-plus mr-1"></i>
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}