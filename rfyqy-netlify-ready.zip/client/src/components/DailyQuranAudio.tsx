import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { useLocalStorage } from "@/hooks/useLocalStorage";

type Reciter = {
  id: string;
  name: string;
};

type ReadingPlan = {
  id: string;
  name: string;
  duration: number; // days to complete
  pagesPerDay: number;
};

type QuranProgress = {
  planId: string;
  currentPage: number;
  totalPages: number;
  lastReadDate: string; // ISO date string
  completedDays: number;
  currentJuz: number;
  currentSurah: number;
  audioPosition: number;
};

const RECITERS: Reciter[] = [
  { id: "mishari_rashid_alafasy", name: "مشاري راشد العفاسي" },
  { id: "abdulbasit_abdulsamad", name: "عبد الباسط عبد الصمد" },
  { id: "mahmoud_khalil_alhusary", name: "محمود خليل الحصري" },
  { id: "muhammad_siddiq_minshawi", name: "محمد صديق المنشاوي" },
  { id: "maher_almuaiqly", name: "ماهر المعيقلي" },
  { id: "abdulrahman_alsudais", name: "عبد الرحمن السديس" },
  { id: "saad_alghamdi", name: "سعد الغامدي" },
];

const READING_PLANS: ReadingPlan[] = [
  { id: "juz_daily", name: "جزء يومياً (ختم في 30 يوم)", duration: 30, pagesPerDay: 20 },
  { id: "page_daily", name: "صفحة يومياً", duration: 604, pagesPerDay: 1 },
  { id: "five_pages", name: "5 صفحات يومياً", duration: 121, pagesPerDay: 5 },
  { id: "ten_pages", name: "10 صفحات يومياً", duration: 60, pagesPerDay: 10 },
  { id: "hizb_daily", name: "حزب يومياً (ختم في 60 يوم)", duration: 60, pagesPerDay: 10 },
  { id: "quarter_hizb", name: "ربع حزب يومياً", duration: 240, pagesPerDay: 2.5 },
];

const DEFAULT_PROGRESS: QuranProgress = {
  planId: "juz_daily",
  currentPage: 1,
  totalPages: 604,
  lastReadDate: new Date().toISOString(),
  completedDays: 0,
  currentJuz: 1,
  currentSurah: 1,
  audioPosition: 0,
};

export default function DailyQuranAudio() {
  const [progress, setProgress] = useLocalStorage<QuranProgress>(
    "quran_reading_progress",
    DEFAULT_PROGRESS
  );
  
  const [selectedReciter, setSelectedReciter] = useLocalStorage<string>(
    "selected_reciter",
    "mishari_rashid_alafasy"
  );
  
  const [selectedPlan, setSelectedPlan] = useLocalStorage<string>(
    "selected_plan",
    "juz_daily"
  );
  
  const [autoPlayEnabled, setAutoPlayEnabled] = useLocalStorage<boolean>(
    "auto_play_enabled",
    false
  );
  
  const [pauseForReflection, setPauseForReflection] = useLocalStorage<boolean>(
    "pause_for_reflection",
    true
  );
  
  const [reflectionInterval, setReflectionInterval] = useLocalStorage<number>(
    "reflection_interval",
    5
  );
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const reflectionTimerRef = useRef<number | null>(null);
  
  // Construct audio source URL based on current progress
  const getAudioSourceUrl = () => {
    // In a real implementation, you would use the correct URL scheme for your audio files
    // This is a simplified example
    const pageString = progress.currentPage.toString().padStart(3, '0');
    const reciterId = selectedReciter;
    return `https://www.everyayah.com/data/${reciterId}/PageMp3s/Page${pageString}.mp3`;
  };
  
  // Update plan details when the selected plan changes
  useEffect(() => {
    const plan = READING_PLANS.find(p => p.id === selectedPlan);
    if (plan) {
      setProgress(prev => ({
        ...prev,
        planId: plan.id,
        pagesPerDay: plan.pagesPerDay
      }));
    }
  }, [selectedPlan, setProgress]);
  
  // Handle audio loading and errors
  useEffect(() => {
    if (audioRef.current) {
      const audio = audioRef.current;
      
      const handleLoadedMetadata = () => {
        setDuration(audio.duration);
        setLoading(false);
      };
      
      const handleError = () => {
        setError("حدث خطأ أثناء تحميل الملف الصوتي. يرجى المحاولة لاحقاً.");
        setLoading(false);
      };
      
      audio.addEventListener('loadedmetadata', handleLoadedMetadata);
      audio.addEventListener('error', handleError);
      
      return () => {
        audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
        audio.removeEventListener('error', handleError);
      };
    }
  }, [audioRef, progress.currentPage]);
  
  // Update audio current time display
  useEffect(() => {
    if (audioRef.current && isPlaying) {
      const interval = setInterval(() => {
        if (audioRef.current) {
          setCurrentTime(audioRef.current.currentTime);
        }
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [isPlaying]);
  
  // Handle automatic pausing for reflection
  useEffect(() => {
    if (isPlaying && pauseForReflection) {
      if (reflectionTimerRef.current) {
        clearTimeout(reflectionTimerRef.current);
      }
      
      reflectionTimerRef.current = window.setTimeout(() => {
        pauseAudio();
        showReflectionPrompt();
      }, reflectionInterval * 60 * 1000); // Convert minutes to milliseconds
      
      return () => {
        if (reflectionTimerRef.current) {
          clearTimeout(reflectionTimerRef.current);
        }
      };
    }
  }, [isPlaying, pauseForReflection, reflectionInterval]);
  
  // Play audio
  const playAudio = () => {
    if (audioRef.current) {
      audioRef.current.play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch(err => {
          console.error("Error playing audio:", err);
          setError("حدث خطأ أثناء تشغيل المقطع الصوتي");
        });
    }
  };
  
  // Pause audio
  const pauseAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };
  
  // Toggle play/pause
  const togglePlayPause = () => {
    if (isPlaying) {
      pauseAudio();
    } else {
      playAudio();
    }
  };
  
  // Show reflection prompt
  const showReflectionPrompt = () => {
    // In a real implementation, this could show a dialog or notification
    console.log("Time for reflection");
    // You could implement a proper dialog here
  };
  
  // Handle audio ended event
  const handleAudioEnded = () => {
    setIsPlaying(false);
    
    // Move to the next page
    setProgress(prev => {
      const nextPage = prev.currentPage + 1;
      // If we've reached the end of the Quran, start over
      if (nextPage > prev.totalPages) {
        return { ...prev, currentPage: 1 };
      }
      return { ...prev, currentPage: nextPage };
    });
    
    // If auto-play is enabled, play the next page automatically
    if (autoPlayEnabled) {
      setTimeout(() => {
        playAudio();
      }, 1500); // Brief pause between pages
    }
  };
  
  // Format time (seconds) to MM:SS
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Handle seeking through the audio
  const handleSeek = (values: number[]) => {
    if (audioRef.current) {
      audioRef.current.currentTime = values[0];
      setCurrentTime(values[0]);
    }
  };
  
  // Navigate to a specific page
  const goToPage = (pageNumber: number) => {
    if (pageNumber >= 1 && pageNumber <= progress.totalPages) {
      setProgress(prev => ({ ...prev, currentPage: pageNumber }));
      setCurrentTime(0);
    }
  };
  
  // Calculate progress percentage
  const calculateProgress = () => {
    return (progress.currentPage / progress.totalPages) * 100;
  };
  
  // Get the current plan
  const currentPlan = READING_PLANS.find(p => p.id === selectedPlan) || READING_PLANS[0];
  
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>الختمة الصوتية التلقائية</CardTitle>
          <CardDescription>
            استمع إلى القرآن الكريم يومياً واجعل الختمة جزءاً من روتينك اليومي
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Current reading info */}
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">الصفحة الحالية:</p>
            <div className="flex items-center justify-between">
              <span className="text-xl font-semibold">{progress.currentPage} من {progress.totalPages}</span>
              <div className="flex items-center space-x-2 space-x-reverse">
                <Button 
                  size="icon" 
                  variant="outline" 
                  onClick={() => goToPage(progress.currentPage - 1)}
                  disabled={progress.currentPage <= 1}
                >
                  <i className="fas fa-chevron-right"></i>
                </Button>
                <Button 
                  size="icon" 
                  variant="outline" 
                  onClick={() => goToPage(progress.currentPage + 1)}
                  disabled={progress.currentPage >= progress.totalPages}
                >
                  <i className="fas fa-chevron-left"></i>
                </Button>
              </div>
            </div>
            
            {/* Overall progress bar */}
            <div className="w-full h-1 bg-muted mt-2 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary" 
                style={{ width: `${calculateProgress()}%` }}
              ></div>
            </div>
            
            <p className="text-xs text-muted-foreground text-center mt-1">
              أكملت {Math.floor(calculateProgress())}% من الختمة
              {currentPlan && ` (${progress.completedDays} يوم من ${currentPlan.duration})`}
            </p>
          </div>
          
          {/* Audio player */}
          <div className="space-y-4 mt-6">
            <audio 
              ref={audioRef}
              src={getAudioSourceUrl()} 
              onEnded={handleAudioEnded}
              className="hidden"
            />
            
            {loading ? (
              <div className="flex justify-center py-4">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : error ? (
              <div className="text-center py-4 text-destructive">
                <p>{error}</p>
                <Button 
                  variant="outline" 
                  className="mt-2"
                  onClick={() => {
                    setError(null);
                    setLoading(true);
                    // Attempt to reload the audio
                    if (audioRef.current) {
                      audioRef.current.load();
                    }
                  }}
                >
                  إعادة المحاولة
                </Button>
              </div>
            ) : (
              <>
                {/* Audio controls */}
                <div className="flex items-center justify-center space-x-4 space-x-reverse">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      if (audioRef.current) {
                        audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - 10);
                        setCurrentTime(audioRef.current.currentTime);
                      }
                    }}
                  >
                    <i className="fas fa-backward"></i>
                  </Button>
                  
                  <Button
                    size="lg"
                    className="w-16 h-16 rounded-full"
                    onClick={togglePlayPause}
                  >
                    <i className={`fas fa-${isPlaying ? 'pause' : 'play'} text-xl`}></i>
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      if (audioRef.current) {
                        audioRef.current.currentTime = Math.min(
                          audioRef.current.duration,
                          audioRef.current.currentTime + 10
                        );
                        setCurrentTime(audioRef.current.currentTime);
                      }
                    }}
                  >
                    <i className="fas fa-forward"></i>
                  </Button>
                </div>
                
                {/* Audio progress */}
                <div className="space-y-2">
                  <Slider
                    value={[currentTime]}
                    min={0}
                    max={duration || 100}
                    step={0.1}
                    onValueChange={handleSeek}
                    dir="ltr"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>
              </>
            )}
          </div>
          
          {/* Settings */}
          <div className="space-y-4 pt-6 border-t">
            <h3 className="font-medium">إعدادات الختمة</h3>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">القارئ</label>
              <Select
                value={selectedReciter}
                onValueChange={setSelectedReciter}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر القارئ" />
                </SelectTrigger>
                <SelectContent>
                  {RECITERS.map(reciter => (
                    <SelectItem key={reciter.id} value={reciter.id}>
                      {reciter.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">خطة الختمة</label>
              <Select
                value={selectedPlan}
                onValueChange={setSelectedPlan}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر الخطة" />
                </SelectTrigger>
                <SelectContent>
                  {READING_PLANS.map(plan => (
                    <SelectItem key={plan.id} value={plan.id}>
                      {plan.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">التشغيل التلقائي</label>
              <Switch
                checked={autoPlayEnabled}
                onCheckedChange={setAutoPlayEnabled}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">التوقف للتدبر بعد كل صفحة</label>
              <Switch
                checked={pauseForReflection}
                onCheckedChange={setPauseForReflection}
              />
            </div>
            
            {pauseForReflection && (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <label className="text-sm font-medium">توقف كل</label>
                  <span className="text-sm">{reflectionInterval} دقائق</span>
                </div>
                <Slider
                  value={[reflectionInterval]}
                  min={1}
                  max={30}
                  step={1}
                  onValueChange={(values) => setReflectionInterval(values[0])}
                  dir="ltr"
                />
              </div>
            )}
          </div>
        </CardContent>
        
        <CardFooter className="flex flex-col space-y-2">
          <p className="text-sm text-muted-foreground text-center">
            استمع إلى القرآن الكريم بانتظام واستشعر معانيه مع التوقف للتدبر
          </p>
          
          {currentPlan && (
            <p className="text-xs text-center text-primary">
              بالخطة الحالية ستختم القرآن في {currentPlan.duration} يوم
              {' '}({currentPlan.pagesPerDay} صفحة يومياً)
            </p>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}