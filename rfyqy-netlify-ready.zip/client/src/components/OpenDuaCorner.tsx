import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "@/hooks/use-toast";

type Dua = {
  id: string;
  text: string;
  category: string;
  author: string; // anonymous or username
  timestamp: string;
  ameen_count: number;
  is_featured: boolean;
  has_said_ameen: boolean;
};

type Category = {
  id: string;
  name: string;
};

// Sample categories
const DUA_CATEGORIES: Category[] = [
  { id: "health", name: "الصحة والشفاء" },
  { id: "family", name: "الأسرة والأهل" },
  { id: "success", name: "النجاح والتوفيق" },
  { id: "forgiveness", name: "المغفرة والتوبة" },
  { id: "protection", name: "الحماية والحفظ" },
  { id: "rizq", name: "الرزق والبركة" },
  { id: "happiness", name: "السعادة والراحة" },
  { id: "knowledge", name: "العلم والمعرفة" },
  { id: "others", name: "أخرى" },
];

// Sample featured duas
const FEATURED_DUAS: Dua[] = [
  {
    id: "f1",
    text: "اللهم إني أسألك العفو والعافية في الدنيا والآخرة، اللهم إني أسألك العفو والعافية في ديني ودنياي وأهلي ومالي",
    category: "protection",
    author: "الإدارة",
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    ameen_count: 254,
    is_featured: true,
    has_said_ameen: false
  },
  {
    id: "f2",
    text: "اللهم اغفر لي ذنبي كله، دقه وجله، وأوله وآخره، وعلانيته وسره",
    category: "forgiveness",
    author: "الإدارة",
    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    ameen_count: 187,
    is_featured: true,
    has_said_ameen: false
  },
  {
    id: "f3",
    text: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
    category: "others",
    author: "الإدارة",
    timestamp: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString(),
    ameen_count: 321,
    is_featured: true,
    has_said_ameen: false
  }
];

export default function OpenDuaCorner() {
  const [duas, setDuas] = useLocalStorage<Dua[]>("open_dua_corner", [...FEATURED_DUAS]);
  const [newDuaText, setNewDuaText] = useState("");
  const [newDuaCategory, setNewDuaCategory] = useState("others");
  const [authorName, setAuthorName] = useState("مستخدم مجهول");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState<string>("featured");
  
  const { toast } = useToast();
  
  // Filter duas based on category and search term
  const filteredDuas = duas.filter(dua => {
    const matchesCategory = !selectedCategory || dua.category === selectedCategory;
    const matchesSearch = !searchTerm || 
      dua.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dua.author.toLowerCase().includes(searchTerm.toLowerCase());
    
    const isFeatured = dua.is_featured;
    
    return matchesCategory && matchesSearch && (activeTab === "featured" ? isFeatured : true);
  }).sort((a, b) => {
    // Sort by timestamp (newest first) or ameen count
    if (activeTab === "popular") {
      return b.ameen_count - a.ameen_count;
    }
    return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
  });
  
  // Add a new dua
  const handleAddDua = () => {
    if (!newDuaText.trim()) {
      toast({
        title: "نص الدعاء فارغ",
        description: "يرجى كتابة الدعاء قبل الإضافة",
        variant: "destructive",
      });
      return;
    }
    
    const newDua: Dua = {
      id: crypto.randomUUID(),
      text: newDuaText.trim(),
      category: newDuaCategory,
      author: authorName || "مستخدم مجهول",
      timestamp: new Date().toISOString(),
      ameen_count: 0,
      is_featured: false,
      has_said_ameen: false
    };
    
    setDuas([newDua, ...duas]);
    setNewDuaText("");
    
    toast({
      title: "تمت إضافة الدعاء",
      description: "جزاك الله خيرًا على مشاركة دعائك",
    });
  };
  
  // Say Ameen to a dua
  const handleSayAmeen = (duaId: string) => {
    setDuas(prev => prev.map(dua => {
      if (dua.id === duaId && !dua.has_said_ameen) {
        return {
          ...dua,
          ameen_count: dua.ameen_count + 1,
          has_said_ameen: true
        };
      }
      return dua;
    }));
    
    toast({
      title: "اللهم آمين",
      description: "تم تسجيل آمين على هذا الدعاء",
    });
  };
  
  // Format timestamp to relative time (e.g., "2 days ago")
  const formatRelativeTime = (timestamp: string) => {
    const now = new Date();
    const date = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return "الآن";
    }
    
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
      return `منذ ${diffInMinutes} دقيقة`;
    }
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return `منذ ${diffInHours} ساعة`;
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 30) {
      return `منذ ${diffInDays} يوم`;
    }
    
    const diffInMonths = Math.floor(diffInDays / 30);
    return `منذ ${diffInMonths} شهر`;
  };
  
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>ركن الدعاء المفتوح</CardTitle>
          <CardDescription>
            شارك دعاءك مع المسلمين حول العالم وقل آمين على أدعية إخوانك
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Add new dua */}
          <div className="space-y-3 bg-muted p-4 rounded-lg">
            <h3 className="font-medium text-sm">إضافة دعاء جديد</h3>
            
            <Textarea
              placeholder="اكتب دعاءك هنا..."
              value={newDuaText}
              onChange={(e) => setNewDuaText(e.target.value)}
              className="min-h-[100px]"
            />
            
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1">
                <Select
                  value={newDuaCategory}
                  onValueChange={setNewDuaCategory}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="اختر تصنيف الدعاء" />
                  </SelectTrigger>
                  <SelectContent>
                    {DUA_CATEGORIES.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex-1">
                <Input
                  placeholder="اسمك (اختياري)"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                />
              </div>
              
              <Button onClick={handleAddDua}>
                إضافة الدعاء
              </Button>
            </div>
          </div>
          
          {/* Browse duas */}
          <div className="pt-4">
            <div className="flex flex-col sm:flex-row gap-3 mb-4 justify-between">
              <Tabs defaultValue="featured" value={activeTab} onValueChange={setActiveTab}>
                <TabsList>
                  <TabsTrigger value="featured">مختارات</TabsTrigger>
                  <TabsTrigger value="recent">أحدث الأدعية</TabsTrigger>
                  <TabsTrigger value="popular">الأكثر دعاءً</TabsTrigger>
                </TabsList>
              </Tabs>
              
              <div className="flex gap-2">
                <Select
                  value={selectedCategory || ""}
                  onValueChange={(value) => setSelectedCategory(value || null)}
                >
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="جميع التصنيفات" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">جميع التصنيفات</SelectItem>
                    {DUA_CATEGORIES.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Input
                  placeholder="بحث..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-[160px]"
                />
              </div>
            </div>
            
            {/* Duas list */}
            <div className="space-y-4">
              {filteredDuas.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground">
                  لا توجد أدعية متاحة. كن أول من يضيف دعاء!
                </div>
              ) : (
                filteredDuas.map((dua) => (
                  <Card key={dua.id} className="overflow-hidden">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <span className="text-sm font-medium">
                            {dua.author}
                          </span>
                          <span className="text-xs text-muted-foreground mx-2">•</span>
                          <span className="text-xs text-muted-foreground">
                            {formatRelativeTime(dua.timestamp)}
                          </span>
                        </div>
                        
                        <span className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                          {DUA_CATEGORIES.find(c => c.id === dua.category)?.name || "أخرى"}
                        </span>
                      </div>
                      
                      <p className="text-lg font-medium leading-relaxed mb-4">{dua.text}</p>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <span>{dua.ameen_count}</span>
                          <span className="text-xs">قالوا آمين</span>
                        </div>
                        
                        <Button
                          variant={dua.has_said_ameen ? "outline" : "default"}
                          size="sm"
                          onClick={() => !dua.has_said_ameen && handleSayAmeen(dua.id)}
                          disabled={dua.has_said_ameen}
                        >
                          {dua.has_said_ameen ? "تم الدعاء" : "اللهم آمين"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="flex-col space-y-2">
          <div className="text-center text-sm text-muted-foreground">
            <p>"وقال ربكم ادعوني أستجب لكم" - سورة غافر: 60</p>
          </div>
          
          <div className="text-center text-xs text-muted-foreground">
            <p>يرجى الالتزام بآداب الدعاء وتجنب نشر المعلومات الشخصية أو أي محتوى غير لائق.</p>
          </div>
        </CardFooter>
      </Card>
      
      {/* Dua etiquette card */}
      <Card>
        <CardHeader>
          <CardTitle>آداب الدعاء</CardTitle>
        </CardHeader>
        
        <CardContent>
          <ul className="space-y-2 list-disc list-inside text-sm">
            <li>الإخلاص والثقة بالله واليقين بالإجابة</li>
            <li>استقبال القبلة ورفع اليدين</li>
            <li>الثناء على الله تعالى والصلاة على النبي في بداية الدعاء ونهايته</li>
            <li>اغتنام أوقات الإجابة مثل الثلث الأخير من الليل ويوم الجمعة</li>
            <li>عدم الاستعجال وتكرار الدعاء</li>
            <li>خفض الصوت والتضرع والخشوع</li>
            <li>التوسل إلى الله بأسمائه وصفاته</li>
            <li>تجنب الدعاء بالإثم أو قطيعة الرحم</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}