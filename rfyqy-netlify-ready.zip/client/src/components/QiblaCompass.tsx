import { useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { Compass } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQiblaDirection } from "@/hooks/useQiblaDirection";
import { useGeolocation } from "@/hooks/useGeolocation";

export default function QiblaCompass() {
  const { t } = useTranslation();
  const { coords, error: geoError } = useGeolocation();
  const compassRef = useRef<HTMLDivElement>(null);
  const [deviceOrientation, setDeviceOrientation] = useState<number>(0);
  const { qiblaDirection, error: qiblaError } = useQiblaDirection(coords?.latitude, coords?.longitude);
  const [compassDirection, setCompassDirection] = useState<number>(0);
  const [directionText, setDirectionText] = useState<string>("");

  // Handle device orientation updates
  useEffect(() => {
    function handleOrientation(event: DeviceOrientationEvent) {
      // Alpha represents compass direction (0-360)
      if (event.alpha !== null) {
        setDeviceOrientation(event.alpha);
      }
    }

    // Request permission for device orientation (for iOS 13+)
    const requestPermission = async () => {
      if (typeof DeviceOrientationEvent !== 'undefined' && 
          typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
        try {
          const permission = await (DeviceOrientationEvent as any).requestPermission();
          if (permission === 'granted') {
            window.addEventListener('deviceorientation', handleOrientation, true);
          }
        } catch (error) {
          console.error("Error requesting device orientation permission:", error);
        }
      } else {
        // For non-iOS devices or iOS devices < 13
        window.addEventListener('deviceorientation', handleOrientation, true);
      }
    };

    requestPermission();

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, []);

  // Update compass needle when device orientation or qibla direction changes
  useEffect(() => {
    if (qiblaDirection !== null) {
      // Combine device orientation with qibla direction to point needle correctly
      const direction = (360 + qiblaDirection - deviceOrientation) % 360;
      setCompassDirection(direction);

      // Determine the direction text
      let dirText = "";
      if (direction >= 337.5 || direction < 22.5) dirText = t("qibla.north");
      else if (direction >= 22.5 && direction < 67.5) dirText = t("qibla.northeast");
      else if (direction >= 67.5 && direction < 112.5) dirText = t("qibla.east");
      else if (direction >= 112.5 && direction < 157.5) dirText = t("qibla.southeast");
      else if (direction >= 157.5 && direction < 202.5) dirText = t("qibla.south");
      else if (direction >= 202.5 && direction < 247.5) dirText = t("qibla.southwest");
      else if (direction >= 247.5 && direction < 292.5) dirText = t("qibla.west");
      else if (direction >= 292.5 && direction < 337.5) dirText = t("qibla.northwest");

      setDirectionText(dirText);
    }
  }, [deviceOrientation, qiblaDirection, t]);

  if (geoError || qiblaError) {
    return (
      <Card className="mt-4 overflow-hidden rounded-xl shadow-md">
        <CardHeader className="bg-primary text-white p-4">
          <CardTitle className="text-xl font-bold flex items-center gap-2">
            <Compass className="h-5 w-5" />
            {t("qibla.title")}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 text-center">
          <div className="text-red-500 mb-4">{t("general.error")}</div>
          <p className="text-sm">يجب السماح للتطبيق بالوصول إلى موقعك وحساسات الجهاز لتحديد اتجاه القبلة.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mt-4 overflow-hidden rounded-xl shadow-md">
      <CardHeader className="bg-primary text-white p-4">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Compass className="h-5 w-5" />
          {t("qibla.title")}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 flex flex-col items-center">
        {/* Compass */}
        <div className="relative w-64 h-64 mb-4" ref={compassRef}>
          {/* Compass Background */}
          <div className="absolute inset-0 rounded-full border-4 border-primary-light bg-white flex items-center justify-center">
            {/* Compass Cardinal Directions */}
            <div className="absolute top-2 text-center text-sm text-primary-dark">{t("qibla.north")}</div>
            <div className="absolute bottom-2 text-center text-sm text-primary-dark">{t("qibla.south")}</div>
            <div className="absolute left-2 text-center text-sm text-primary-dark">{t("qibla.west")}</div>
            <div className="absolute right-2 text-center text-sm text-primary-dark">{t("qibla.east")}</div>
            
            {/* Compass Rose Lines */}
            <div className="absolute h-full w-[1px] bg-gray-300"></div>
            <div className="absolute h-[1px] w-full bg-gray-300"></div>
            
            {/* Compass Needle */}
            <div 
              className="compass-needle w-1 h-32 bg-gradient-to-b from-red-500 to-primary relative"
              style={{ transform: `rotate(${compassDirection}deg)` }}
            >
              <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-red-500 rounded-full"></div>
            </div>
            
            {/* Kaaba Marker */}
            <div className="absolute" style={{ top: "10%", right: "15%" }}>
              <div className="w-10 h-10 bg-black rounded-sm flex items-center justify-center">
                <div className="w-6 h-6 border-2 border-primary"></div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Kaaba Image */}
        <img 
          src="https://images.unsplash.com/photo-1537444532052-2afbf769b76c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300" 
          alt="الكعبة المشرفة بمكة المكرمة" 
          className="rounded-lg shadow-md w-full h-auto mt-4" 
        />
        
        {/* Direction Information */}
        <div className="text-center mt-4">
          <p className="text-primary-dark font-bold">
            {t("qibla.direction", { degrees: qiblaDirection?.toFixed(0), direction: directionText })}
          </p>
          <p className="text-sm text-gray-600">{t("qibla.calibrateMessage")}</p>
        </div>
      </CardContent>
    </Card>
  );
}
