import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Church } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { usePrayerTimes } from "@/hooks/usePrayerTimes";
import { useGeolocation } from "@/hooks/useGeolocation";

type Prayer = {
  name: string;
  time: string;
  isCurrent: boolean;
};

export default function PrayerTimesCard() {
  const { t } = useTranslation();
  const { coords, error: geoError } = useGeolocation();
  const { data, isLoading, error } = usePrayerTimes(coords?.latitude, coords?.longitude);
  const [currentPrayer, setCurrentPrayer] = useState<string | null>(null);
  const [nextPrayer, setNextPrayer] = useState<string | null>(null);
  const [minutesToNextPrayer, setMinutesToNextPrayer] = useState<number | null>(null);
  const [prayersList, setPrayersList] = useState<Prayer[]>([]);
  const [locationName, setLocationName] = useState<string>("...");
  const [hijriDate, setHijriDate] = useState<string>("...");

  useEffect(() => {
    if (data) {
      const { timings, meta, date } = data;
      
      // Update location name
      setLocationName(meta?.timezone || "");
      
      // Update hijri date
      setHijriDate(`${date.hijri.day} ${date.hijri.month.ar} ${date.hijri.year}`);
      
      // Create prayers list
      const prayers = [
        { name: t("prayer.fajr"), time: timings.Fajr, isCurrent: false },
        { name: t("prayer.sunrise"), time: timings.Sunrise, isCurrent: false },
        { name: t("prayer.dhuhr"), time: timings.Dhuhr, isCurrent: false },
        { name: t("prayer.asr"), time: timings.Asr, isCurrent: false },
        { name: t("prayer.maghrib"), time: timings.Maghrib, isCurrent: false },
        { name: t("prayer.isha"), time: timings.Isha, isCurrent: false },
      ];
      
      // Find current and next prayer
      const now = new Date();
      const todayStr = now.toISOString().split('T')[0];
      
      let currentIdx = -1;
      for (let i = 0; i < prayers.length; i++) {
        const prayerTime = new Date(`${todayStr}T${prayers[i].time}`);
        const nextPrayerTime = i < prayers.length - 1 
          ? new Date(`${todayStr}T${prayers[i + 1].time}`)
          : new Date(`${todayStr}T23:59:59`);
          
        if (now >= prayerTime && now < nextPrayerTime) {
          currentIdx = i;
          break;
        }
      }
      
      // If we couldn't find the current prayer, default to Isha
      if (currentIdx === -1) currentIdx = 5;
      
      // Mark current prayer
      prayers[currentIdx].isCurrent = true;
      setCurrentPrayer(prayers[currentIdx].name);
      
      // Calculate next prayer and minutes remaining
      const nextIdx = (currentIdx + 1) % prayers.length;
      setNextPrayer(prayers[nextIdx].name);
      
      // Calculate minutes to next prayer
      const nowMs = now.getTime();
      let nextPrayerTime = new Date(`${todayStr}T${prayers[nextIdx].time}`).getTime();
      
      // If next prayer is tomorrow's Fajr
      if (nextIdx === 0 && currentIdx === prayers.length - 1) {
        const tomorrow = new Date(now);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const tomorrowStr = tomorrow.toISOString().split('T')[0];
        nextPrayerTime = new Date(`${tomorrowStr}T${prayers[0].time}`).getTime();
      }
      
      const diffMinutes = Math.round((nextPrayerTime - nowMs) / (1000 * 60));
      setMinutesToNextPrayer(diffMinutes);
      
      setPrayersList(prayers);
    }
  }, [data, t]);

  if (isLoading) {
    return (
      <Card className="mt-4">
        <CardHeader className="bg-primary text-white">
          <CardTitle className="flex items-center gap-2">
            <Church className="h-5 w-5" />
            {t("prayer.title")}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="text-center py-8">{t("general.loading")}</div>
        </CardContent>
      </Card>
    );
  }

  if (error || geoError) {
    return (
      <Card className="mt-4">
        <CardHeader className="bg-primary text-white">
          <CardTitle className="flex items-center gap-2">
            <Church className="h-5 w-5" />
            {t("prayer.title")}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="text-center py-4 text-red-500">{t("general.error")}</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mt-4 overflow-hidden rounded-xl shadow-md">
      <CardHeader className="bg-primary text-white p-4">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Church className="h-5 w-5" />
          {t("prayer.title")}
        </CardTitle>
        <div className="flex justify-between items-center mt-2 text-sm">
          <span>{locationName}</span>
          <span>{hijriDate}</span>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        {/* Current Prayer Highlight */}
        <div className="bg-primary-bg rounded-lg p-3 mb-4 flex justify-between items-center">
          <div>
            <h3 className="font-bold text-primary">{t("prayer.currentPrayer")}: {currentPrayer}</h3>
            <p className="text-sm text-gray-600">
              {t("prayer.nextPrayer")}: {nextPrayer} ({t("prayer.afterMinutes", { minutes: minutesToNextPrayer })})
            </p>
          </div>
          <div className="prayer-time-pulse text-primary-dark font-bold">
            {prayersList.find(p => p.isCurrent)?.time}
          </div>
        </div>
        
        {/* Prayer Times List */}
        <div className="grid grid-cols-2 gap-3">
          {prayersList.map((prayer, index) => (
            <div key={index} className="flex justify-between p-2 border-b border-gray-100">
              <span className="font-medium">{prayer.name}</span>
              <span className={prayer.isCurrent ? "font-bold text-primary" : ""}>{prayer.time}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
