import { useTranslation } from "react-i18next";
import { useLocation, Link } from "wouter";
import { 
  Home, 
  BookOpen, 
  HandHelping, 
  Compass, 
  Bot, 
  Moon, 
  ListTodo, 
  MapPin, 
  PenTool, 
  Share2 
} from "lucide-react";

export default function BottomNavigation() {
  const { t } = useTranslation();
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  // Main navigation items - always visible
  const mainNavItems = [
    { path: "/", icon: <Home size={20} className="mb-1" />, label: t("nav.home") },
    { path: "/quran", icon: <BookOpen size={20} className="mb-1" />, label: t("nav.quran") },
    { path: "/adhkar", icon: <HandHelping size={20} className="mb-1" />, label: t("nav.adhkar") },
    { path: "/qibla", icon: <Compass size={20} className="mb-1" />, label: t("nav.qibla") },
    { path: "/more", icon: <i className="fas fa-ellipsis-h text-lg mb-1"></i>, label: t("nav.more") },
  ];

  return (
    <nav className="fixed bottom-0 right-0 left-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 py-2 px-4 z-10">
      <div className="container mx-auto">
        <div className="flex justify-around items-center">
          {mainNavItems.map((item) => (
            <Link href={item.path} key={item.path}>
              <a className={`flex flex-col items-center ${
                isActive(item.path) ? "text-primary" : "text-gray-500 hover:text-primary"
              }`}>
                {item.icon}
                <span className="text-xs">{item.label}</span>
              </a>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
