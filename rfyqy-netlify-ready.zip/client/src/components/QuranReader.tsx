import { useState } from "react";
import { useTranslation } from "react-i18next";
import { BookOpen, Search, Bookmark } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { useLocalStorage } from "@/hooks/useLocalStorage";

type Surah = {
  id: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
};

type LastRead = {
  surah: number;
  ayah: number;
  juz: number;
};

export default function QuranReader() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState("");
  const [lastRead, setLastRead] = useLocalStorage<LastRead | null>("quran-last-read", null);
  const [favorites, setFavorites] = useLocalStorage<number[]>("quran-favorites", []);
  const [showFavorites, setShowFavorites] = useState(false);

  const { data: surahs, isLoading, error } = useQuery({
    queryKey: ["/api/quran/surahs"],
  });

  const { data: lastReadSurah } = useQuery({
    queryKey: ["/api/quran/surah", lastRead?.surah],
    enabled: !!lastRead,
  });

  const filteredSurahs = showFavorites 
    ? surahs?.filter((surah: Surah) => favorites.includes(surah.id))
    : surahs?.filter((surah: Surah) => 
        surah.name.includes(searchQuery) || 
        surah.englishName.toLowerCase().includes(searchQuery.toLowerCase())
      );

  const handleOpenSurah = (surahId: number) => {
    // In a real app, we would navigate to the surah page
    if (!lastRead || lastRead.surah !== surahId) {
      setLastRead({
        surah: surahId,
        ayah: 1,
        juz: 1, // This would be determined based on the ayah
      });
    }
  };

  const continueReading = () => {
    // In a real app, we would navigate to the last read position
    if (lastRead) {
      console.log(`Continue reading from Surah ${lastRead.surah}, Ayah ${lastRead.ayah}`);
    }
  };

  const toggleFavorites = () => {
    setShowFavorites(!showFavorites);
  };

  return (
    <Card className="mt-4 overflow-hidden rounded-xl shadow-md">
      <CardHeader className="bg-primary text-white p-4">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          {t("quran.title")}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        {/* Search & Favorites */}
        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Input
              type="text"
              placeholder={t("quran.search")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2"
            />
            <span className="absolute left-3 top-2.5 text-gray-400">
              <Search className="h-4 w-4" />
            </span>
          </div>
          <Button
            variant={showFavorites ? "default" : "outline"}
            className={showFavorites ? "bg-primary" : ""}
            onClick={toggleFavorites}
          >
            <Bookmark className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Recently Read & Quran Images */}
        {lastRead && (
          <div className="mb-4">
            <h3 className="font-bold text-primary mb-2">{t("quran.lastRead")}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Quran reading image */}
              <img 
                src="https://images.unsplash.com/photo-1609599006353-e629aaabfeae?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300" 
                alt="قراءة القرآن" 
                className="rounded-lg shadow-md w-full h-auto" 
              />
              
              {/* Last read card */}
              <div className="bg-primary-bg rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-bold">{lastReadSurah?.name || `سورة رقم ${lastRead.surah}`}</h4>
                  <span className="text-primary text-sm">{t("quran.juz")} {lastRead.juz}</span>
                </div>
                <p className="text-gray-700 mb-3">{t("quran.lastRead")}: {t("quran.ayah")} {lastRead.ayah}</p>
                <Button 
                  variant="default" 
                  className="w-full bg-primary hover:bg-primary-dark"
                  onClick={continueReading}
                >
                  {t("quran.continueReading")}
                </Button>
              </div>
            </div>
          </div>
        )}
        
        {/* Surahs List */}
        <div>
          <h3 className="font-bold text-primary mb-2">{t("quran.surahs")}</h3>
          
          {isLoading ? (
            <div className="text-center py-8">{t("general.loading")}</div>
          ) : error ? (
            <div className="text-center py-4 text-red-500">{t("general.error")}</div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              {filteredSurahs?.slice(0, 8).map((surah: Surah) => (
                <div 
                  key={surah.id} 
                  className="border border-gray-200 rounded-lg p-3 hover:bg-primary-bg cursor-pointer"
                  onClick={() => handleOpenSurah(surah.id)}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-bold">{surah.name}</h4>
                      <p className="text-xs text-gray-600">{surah.numberOfAyahs} {t("quran.ayat")}</p>
                    </div>
                    <div className="w-8 h-8 bg-primary-light rounded-full text-white flex items-center justify-center">
                      {surah.id}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          <Button 
            variant="outline" 
            className="w-full mt-3 text-gray-700"
            onClick={() => alert(t("quran.viewAll"))}
          >
            {t("quran.viewAll")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
