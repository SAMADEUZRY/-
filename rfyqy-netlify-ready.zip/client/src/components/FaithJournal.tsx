import { useState, useEffect } from "react";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

type JournalEntry = {
  id: string;
  title: string;
  content: string;
  category: string;
  date: string; // ISO string
  mood: string;
  isPrivate: boolean;
};

const JOURNAL_CATEGORIES = [
  { id: "prayer_experience", name: "تجربة صلاة" },
  { id: "dua_answered", name: "دعاء مستجاب" },
  { id: "quran_reflection", name: "تأمل في القرآن" },
  { id: "spiritual_lesson", name: "درس روحاني" },
  { id: "gratitude", name: "شكر وامتنان" },
  { id: "struggle", name: "تحدي وصبر" },
  { id: "goals", name: "أهداف إيمانية" },
  { id: "dream", name: "رؤيا/حلم" },
  { id: "other", name: "أخرى" },
];

const MOOD_OPTIONS = [
  { id: "peaceful", name: "هادئ", icon: "fa-peace" },
  { id: "hopeful", name: "متفائل", icon: "fa-sun" },
  { id: "grateful", name: "ممتن", icon: "fa-pray" },
  { id: "inspired", name: "ملهم", icon: "fa-lightbulb" },
  { id: "reflective", name: "متأمل", icon: "fa-book" },
  { id: "challenged", name: "متحدي", icon: "fa-mountain" },
  { id: "confused", name: "حائر", icon: "fa-question" },
  { id: "sad", name: "حزين", icon: "fa-cloud-rain" },
];

export default function FaithJournal() {
  const [entries, setEntries] = useLocalStorage<JournalEntry[]>("faith_journal_entries", []);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [currentEntry, setCurrentEntry] = useState<JournalEntry | null>(null);
  const [newEntry, setNewEntry] = useState<Omit<JournalEntry, "id" | "date">>({
    title: "",
    content: "",
    category: "",
    mood: "peaceful",
    isPrivate: false,
  });
  
  const { toast } = useToast();

  const filteredEntries = entries.filter((entry) => {
    const matchesSearch = searchTerm === "" 
      ? true 
      : entry.title.includes(searchTerm) || entry.content.includes(searchTerm);
    
    const matchesCategory = filterCategory === "" 
      ? true 
      : entry.category === filterCategory;
    
    return matchesSearch && matchesCategory;
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleAddEntry = () => {
    if (!newEntry.title || !newEntry.content || !newEntry.category) {
      toast({
        title: "بيانات غير مكتملة",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive",
      });
      return;
    }

    const entry: JournalEntry = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      ...newEntry,
    };

    setEntries([...entries, entry]);
    setIsAddDialogOpen(false);
    resetNewEntry();

    toast({
      title: "تمت الإضافة",
      description: "تمت إضافة التسجيل بنجاح إلى مذكراتك الإيمانية",
    });
  };

  const handleDeleteEntry = (id: string) => {
    setEntries(entries.filter((entry) => entry.id !== id));
    setIsViewDialogOpen(false);
    setCurrentEntry(null);

    toast({
      title: "تم الحذف",
      description: "تم حذف التسجيل من مذكراتك الإيمانية",
    });
  };

  const resetNewEntry = () => {
    setNewEntry({
      title: "",
      content: "",
      category: "",
      mood: "peaceful",
      isPrivate: false,
    });
  };

  const openViewDialog = (entry: JournalEntry) => {
    setCurrentEntry(entry);
    setIsViewDialogOpen(true);
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    };
    return new Date(dateString).toLocaleDateString("ar-SA", options);
  };

  const getPrompt = () => {
    const prompts = [
      "ما هو أكثر شيء أشعرك بالقرب من الله اليوم؟",
      "هل استجاب الله دعاءً لك مؤخراً؟ ما هو وكيف شعرت؟",
      "ما هي الآية التي تأملت فيها اليوم وماذا تعلمت منها؟",
      "ما هو التحدي الروحاني الذي تواجهه حالياً؟",
      "كيف تغير إيمانك خلال الشهر الماضي؟",
      "ما هي النعمة التي لاحظتها اليوم ولم تكن تنتبه لها من قبل؟",
      "ما هو الدعاء الذي تكرره دائماً وما سبب أهميته بالنسبة لك؟",
      "هل شعرت بسكينة خاصة أثناء الصلاة اليوم؟ صف شعورك."
    ];
    return prompts[Math.floor(Math.random() * prompts.length)];
  };

  return (
    <div className="space-y-4 p-4">
      <h2 className="text-2xl font-bold text-center">المذكرات الإيمانية</h2>
      <p className="text-center text-muted-foreground">
        سجل تجاربك الروحية وتأملاتك واللحظات المميزة في رحلتك الإيمانية
      </p>

      <div className="flex flex-col sm:flex-row gap-2 sm:items-center justify-between">
        <div className="flex-1">
          <Input 
            placeholder="ابحث في مذكراتك..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="w-full sm:w-48">
          <Select
            value={filterCategory}
            onValueChange={setFilterCategory}
          >
            <SelectTrigger>
              <SelectValue placeholder="كل الفئات" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">كل الفئات</SelectItem>
              {JOURNAL_CATEGORIES.map((category) => (
                <SelectItem key={category.id} value={category.id}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <i className="fas fa-plus ml-2"></i>
          إضافة
        </Button>
      </div>

      {filteredEntries.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <p className="text-muted-foreground mb-6">لا توجد مذكرات بعد. ابدأ بتسجيل تجاربك الإيمانية.</p>
            <Button 
              variant="outline" 
              className="mx-auto"
              onClick={() => setIsAddDialogOpen(true)}
            >
              أضف أول مذكرة
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredEntries.map((entry) => (
            <Card 
              key={entry.id} 
              className="cursor-pointer hover:border-primary transition-colors"
              onClick={() => openViewDialog(entry)}
            >
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg truncate">{entry.title}</CardTitle>
                  {entry.isPrivate && (
                    <i className="fas fa-lock text-muted-foreground"></i>
                  )}
                </div>
                <CardDescription className="flex items-center justify-between">
                  <span>
                    {JOURNAL_CATEGORIES.find(c => c.id === entry.category)?.name}
                  </span>
                  <span className="text-sm">{formatDate(entry.date)}</span>
                </CardDescription>
              </CardHeader>
              <CardContent className="pb-4">
                <p className="line-clamp-3 text-sm">
                  {entry.content}
                </p>
              </CardContent>
              <CardFooter className="pt-0 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <i className={`fas ${MOOD_OPTIONS.find(m => m.id === entry.mood)?.icon} mr-1`}></i>
                  <span>{MOOD_OPTIONS.find(m => m.id === entry.mood)?.name}</span>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Add Entry Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>إضافة مذكرة جديدة</DialogTitle>
            <DialogDescription>
              سجل تجربة روحانية أو تأملاً في القرآن أو دعاءً مستجاباً
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">عنوان المذكرة</label>
              <Input
                placeholder="عنوان وصفي للمذكرة..."
                value={newEntry.title}
                onChange={(e) => setNewEntry({ ...newEntry, title: e.target.value })}
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <label className="text-sm font-medium">المحتوى</label>
                <button 
                  onClick={() => navigator.clipboard.writeText(getPrompt())}
                  className="text-xs text-muted-foreground hover:text-primary"
                >
                  <i className="fas fa-lightbulb mr-1"></i>
                  اقتراح للكتابة
                </button>
              </div>
              <Textarea
                placeholder={getPrompt()}
                className="min-h-[180px]"
                value={newEntry.content}
                onChange={(e) => setNewEntry({ ...newEntry, content: e.target.value })}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">الفئة</label>
              <Select
                value={newEntry.category}
                onValueChange={(value) => setNewEntry({ ...newEntry, category: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر فئة" />
                </SelectTrigger>
                <SelectContent>
                  {JOURNAL_CATEGORIES.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">الحالة المزاجية</label>
              <div className="grid grid-cols-4 gap-2">
                {MOOD_OPTIONS.map((mood) => (
                  <Button
                    key={mood.id}
                    type="button"
                    variant={newEntry.mood === mood.id ? "default" : "outline"}
                    className="h-16"
                    onClick={() => setNewEntry({ ...newEntry, mood: mood.id })}
                  >
                    <div className="flex flex-col items-center gap-1">
                      <i className={`fas ${mood.icon} text-lg`}></i>
                      <span className="text-xs">{mood.name}</span>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
            
            <div className="flex items-center space-x-2 space-x-reverse">
              <input
                type="checkbox"
                id="private"
                checked={newEntry.isPrivate}
                onChange={(e) => setNewEntry({ ...newEntry, isPrivate: e.target.checked })}
              />
              <label htmlFor="private" className="text-sm font-medium">
                خاص (تشفير المحتوى)
              </label>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              إلغاء
            </Button>
            <Button onClick={handleAddEntry}>
              حفظ المذكرة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Entry Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          {currentEntry && (
            <>
              <DialogHeader>
                <DialogTitle>{currentEntry.title}</DialogTitle>
                <DialogDescription className="flex justify-between">
                  <span>{JOURNAL_CATEGORIES.find(c => c.id === currentEntry.category)?.name}</span>
                  <span>{formatDate(currentEntry.date)}</span>
                </DialogDescription>
              </DialogHeader>
              
              <div className="py-4">
                <div className="flex items-center gap-2 mb-4 text-sm">
                  <div className="bg-muted px-3 py-1 rounded-full flex items-center">
                    <i className={`fas ${MOOD_OPTIONS.find(m => m.id === currentEntry.mood)?.icon} mr-1`}></i>
                    <span>{MOOD_OPTIONS.find(m => m.id === currentEntry.mood)?.name}</span>
                  </div>
                  
                  {currentEntry.isPrivate && (
                    <div className="bg-muted px-3 py-1 rounded-full flex items-center">
                      <i className="fas fa-lock mr-1"></i>
                      <span>مذكرة خاصة</span>
                    </div>
                  )}
                </div>
                
                <div className="bg-muted p-4 rounded-md whitespace-pre-line">
                  {currentEntry.content}
                </div>
              </div>
              
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setIsViewDialogOpen(false)}
                >
                  إغلاق
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => handleDeleteEntry(currentEntry.id)}
                >
                  <i className="fas fa-trash-alt ml-2"></i>
                  حذف
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      <div className="bg-muted p-4 rounded-md mt-8">
        <h3 className="text-lg font-semibold mb-2">فوائد تدوين المذكرات الإيمانية</h3>
        <ul className="space-y-1 list-disc list-inside text-muted-foreground">
          <li>تعزيز الوعي الروحي وتنمية الصلة بالله</li>
          <li>توثيق لحظات استجابة الدعاء ومواقف زيادة الإيمان</li>
          <li>التأمل في آيات القرآن وتطبيقها في الحياة اليومية</li>
          <li>مراقبة تطور إيمانك على مر الزمن</li>
          <li>تذكر نعم الله ومنحه في أوقات الشدة</li>
        </ul>
      </div>
    </div>
  );
}