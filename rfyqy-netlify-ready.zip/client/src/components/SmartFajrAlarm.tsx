import { useState, useEffect } from "react";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { usePrayerTimes } from "@/hooks/usePrayerTimes";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

type AlarmSettings = {
  enabled: boolean;
  minutesBefore: number;
  sound: string;
  vibration: boolean;
  requireAction: boolean;
  actionType: "adhkar" | "dua" | "button";
};

const DEFAULT_SETTINGS: AlarmSettings = {
  enabled: false,
  minutesBefore: 30,
  sound: "adhan1",
  vibration: true,
  requireAction: true,
  actionType: "dua",
};

const ALARM_SOUNDS = [
  { id: "adhan1", name: "آذان المسجد النبوي" },
  { id: "adhan2", name: "آذان المسجد الحرام" },
  { id: "adhan3", name: "آذان الحرم الإبراهيمي" },
  { id: "soft_tone", name: "نغمة هادئة" },
  { id: "quran", name: "تلاوة قرآنية فجرية" },
];

const MORNING_DUAS = [
  "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ",
  "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ",
  "الْحَمْدُ لِلَّهِ الَّذِي عَافَانِي فِي جَسَدِي، وَرَدَّ عَلَيَّ رُوحِي، وَأَذِنَ لِي بِذِكْرِهِ",
];

export default function SmartFajrAlarm() {
  const [settings, setSettings] = useLocalStorage<AlarmSettings>(
    "fajr_alarm_settings",
    DEFAULT_SETTINGS
  );
  const [testAlarmOpen, setTestAlarmOpen] = useState<boolean>(false);
  const [fajrTime, setFajrTime] = useState<string>("");
  const [alarmTime, setAlarmTime] = useState<string>("");
  const [activeDialog, setActiveDialog] = useState<boolean>(false);
  const [selectedDua, setSelectedDua] = useState<string>("");
  
  const { coords } = useGeolocation();
  const { toast } = useToast();
  const { prayerTimes, loading, error } = usePrayerTimes(
    coords?.latitude,
    coords?.longitude
  );

  // Set the Fajr time when prayer times are available
  useEffect(() => {
    if (prayerTimes && prayerTimes.length > 0) {
      const fajr = prayerTimes.find((prayer) => prayer.name === "Fajr");
      if (fajr) {
        setFajrTime(fajr.time);
        
        // Calculate the alarm time (minutes before Fajr)
        const fajrDate = new Date();
        const [hours, minutes] = fajr.time.split(":").map(Number);
        fajrDate.setHours(hours, minutes, 0);
        
        const alarmDate = new Date(fajrDate.getTime() - settings.minutesBefore * 60000);
        const alarmHours = alarmDate.getHours();
        const alarmMinutes = alarmDate.getMinutes();
        
        setAlarmTime(
          `${alarmHours.toString().padStart(2, "0")}:${alarmMinutes.toString().padStart(2, "0")}`
        );
      }
    }
  }, [prayerTimes, settings.minutesBefore]);

  // Toggle alarm active state
  const toggleAlarm = () => {
    if (!settings.enabled && (!coords?.latitude || !coords?.longitude)) {
      toast({
        title: "تحديد الموقع مطلوب",
        description: "يرجى السماح بتحديد موقعك لضبط وقت صلاة الفجر بشكل صحيح",
        variant: "destructive",
      });
      return;
    }

    setSettings({
      ...settings,
      enabled: !settings.enabled,
    });

    toast({
      title: !settings.enabled ? "تم تفعيل المنبه" : "تم إيقاف المنبه",
      description: !settings.enabled
        ? `سيتم تنبيهك قبل صلاة الفجر بـ ${settings.minutesBefore} دقيقة`
        : "تم إيقاف منبه صلاة الفجر",
    });
  };

  // Update alarm settings
  const updateSettings = (newSettings: Partial<AlarmSettings>) => {
    setSettings({
      ...settings,
      ...newSettings,
    });
  };

  // Test the alarm functionality
  const testAlarm = () => {
    setTestAlarmOpen(true);
    if (settings.actionType === "dua") {
      setSelectedDua(MORNING_DUAS[Math.floor(Math.random() * MORNING_DUAS.length)]);
    }
  };

  // Dismiss the test alarm
  const dismissTestAlarm = () => {
    setTestAlarmOpen(false);
    toast({
      title: "تم الاختبار بنجاح",
      description: "منبه الفجر الذكي يعمل بشكل جيد",
    });
  };

  return (
    <div className="space-y-4 p-4">
      <h2 className="text-2xl font-bold text-center">منبه الفجر الذكي</h2>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>منبه صلاة الفجر</CardTitle>
              <CardDescription>
                استيقظ لصلاة الفجر بطريقة فعالة
              </CardDescription>
            </div>
            <Switch
              checked={settings.enabled}
              onCheckedChange={toggleAlarm}
              aria-label="تفعيل المنبه"
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {!loading && !error && prayerTimes && (
            <div className="flex flex-col space-y-1">
              <span className="text-sm text-muted-foreground">وقت صلاة الفجر: </span>
              <span className="text-xl font-semibold">{fajrTime}</span>
              
              {settings.enabled && (
                <div className="mt-2">
                  <span className="text-sm text-muted-foreground">المنبه سيعمل في: </span>
                  <span className="text-lg font-medium">{alarmTime}</span>
                </div>
              )}
            </div>
          )}

          <div className="space-y-6 pt-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">عدد الدقائق قبل الفجر</label>
              <div className="flex items-center space-x-4 space-x-reverse justify-between">
                <Slider
                  value={[settings.minutesBefore]}
                  min={5}
                  max={60}
                  step={5}
                  onValueChange={(values) =>
                    updateSettings({ minutesBefore: values[0] })
                  }
                  className="w-[60%]"
                  dir="ltr"
                />
                <span className="w-[40%] text-center font-medium">
                  {settings.minutesBefore} دقيقة
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">صوت المنبه</label>
              <Select
                value={settings.sound}
                onValueChange={(value) => updateSettings({ sound: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ALARM_SOUNDS.map((sound) => (
                    <SelectItem key={sound.id} value={sound.id}>
                      {sound.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">اهتزاز مع الصوت</label>
              <Switch
                checked={settings.vibration}
                onCheckedChange={(checked) =>
                  updateSettings({ vibration: checked })
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">يتطلب إجراء للإيقاف</label>
              <Switch
                checked={settings.requireAction}
                onCheckedChange={(checked) =>
                  updateSettings({ requireAction: checked })
                }
              />
            </div>

            {settings.requireAction && (
              <div className="space-y-2">
                <label className="text-sm font-medium">نوع الإجراء المطلوب</label>
                <Select
                  value={settings.actionType}
                  onValueChange={(value: "adhkar" | "dua" | "button") =>
                    updateSettings({ actionType: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dua">قراءة دعاء الصباح</SelectItem>
                    <SelectItem value="adhkar">قراءة ذكر من أذكار الصباح</SelectItem>
                    <SelectItem value="button">الضغط على زر "استيقظت"</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button
            className="w-full"
            variant="outline"
            onClick={testAlarm}
          >
            اختبار المنبه
          </Button>
        </CardFooter>
      </Card>

      {/* Test Alarm Dialog */}
      <Dialog open={testAlarmOpen} onOpenChange={setTestAlarmOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl">
              <i className="fas fa-mosque text-primary mr-2"></i> حان وقت صلاة الفجر
            </DialogTitle>
            <DialogDescription className="text-center">
              استيقظ لأداء الصلاة والحصول على ثواب عظيم من الله
            </DialogDescription>
          </DialogHeader>

          {settings.actionType === "dua" && (
            <div className="bg-muted p-4 rounded-md my-4 text-center">
              <p className="font-arabic text-lg">{selectedDua}</p>
              <p className="text-sm text-muted-foreground mt-2">
                اقرأ الدعاء بتمعن
              </p>
            </div>
          )}

          {settings.actionType === "adhkar" && (
            <div className="bg-muted p-4 rounded-md my-4 text-center">
              <p className="font-arabic text-lg">
                أصْبَحْنَا وَأصْبَحَ المُلْكُ للهِ، وَالحَمْدُ للهِ، لَا إلَهَ إلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                اقرأ الذكر ثلاث مرات
              </p>
            </div>
          )}

          <DialogFooter className="sm:justify-center">
            <Button
              type="button"
              className="w-full sm:w-auto"
              onClick={dismissTestAlarm}
            >
              {settings.actionType === "button" ? "استيقظت" : "تم القراءة"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}