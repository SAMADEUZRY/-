import { useState, useEffect } from "react";

interface QiblaDirectionState {
  qiblaDirection: number | null;
  error: string | null;
  loading: boolean;
}

export function useQiblaDirection(latitude?: number, longitude?: number) {
  const [state, setState] = useState<QiblaDirectionState>({
    qiblaDirection: null,
    error: null,
    loading: true,
  });

  useEffect(() => {
    if (!latitude || !longitude) {
      setState({
        qiblaDirection: null,
        error: "الموقع الجغرافي غير متاح",
        loading: false,
      });
      return;
    }

    try {
      // Mecca coordinates
      const meccaLat = 21.422487;
      const meccaLong = 39.826206;

      // Convert to radians
      const userLatRad = (latitude * Math.PI) / 180;
      const userLongRad = (longitude * Math.PI) / 180;
      const meccaLatRad = (meccaLat * Math.PI) / 180;
      const meccaLongRad = (meccaLong * Math.PI) / 180;

      // Calculate the direction
      const y = Math.sin(meccaLongRad - userLongRad);
      const x =
        Math.cos(userLatRad) * Math.tan(meccaLatRad) -
        Math.sin(userLatRad) * Math.cos(meccaLongRad - userLongRad);

      // Calculate the angle in degrees from north
      let qiblaAngle = Math.atan2(y, x) * (180 / Math.PI);
      // Normalize to 0-360 degrees
      qiblaAngle = (qiblaAngle + 360) % 360;

      setState({
        qiblaDirection: qiblaAngle,
        error: null,
        loading: false,
      });
    } catch (error) {
      setState({
        qiblaDirection: null,
        error: "حدث خطأ أثناء حساب اتجاه القبلة",
        loading: false,
      });
    }
  }, [latitude, longitude]);

  return state;
}
