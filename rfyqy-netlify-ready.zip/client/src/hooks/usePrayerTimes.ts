import { useQuery } from "@tanstack/react-query";

export function usePrayerTimes(latitude?: number, longitude?: number) {
  return useQuery({
    queryKey: ["/api/prayer-times", latitude, longitude],
    enabled: !!latitude && !!longitude,
    refetchInterval: 1000 * 60 * 15, // Refetch every 15 minutes
  });
}
