import { useState, useEffect } from "react";

interface GeolocationState {
  coords: {
    latitude: number;
    longitude: number;
    accuracy: number;
  } | null;
  error: string | null;
  loading: boolean;
}

export function useGeolocation() {
  const [state, setState] = useState<GeolocationState>({
    coords: null,
    error: null,
    loading: true,
  });

  useEffect(() => {
    if (!navigator.geolocation) {
      setState({
        coords: null,
        error: "الموقع الجغرافي غير مدعوم في هذا المتصفح",
        loading: false,
      });
      return;
    }

    const geoSuccess = (position: GeolocationPosition) => {
      setState({
        coords: {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        },
        error: null,
        loading: false,
      });
    };

    const geoError = (error: GeolocationPositionError) => {
      setState({
        coords: null,
        error: error.message,
        loading: false,
      });
    };

    const watcher = navigator.geolocation.watchPosition(geoSuccess, geoError, {
      enableHighAccuracy: true,
      maximumAge: 30000,
      timeout: 27000,
    });

    return () => {
      navigator.geolocation.clearWatch(watcher);
    };
  }, []);

  return state;
}
