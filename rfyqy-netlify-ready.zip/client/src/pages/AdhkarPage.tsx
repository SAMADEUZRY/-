import { useTranslation } from "react-i18next";
import MorningEveningAdhkar from "@/components/MorningEveningAdhkar";

export default function AdhkarPage() {
  const { t } = useTranslation();
  
  return (
    <main className="container mx-auto px-4 pb-24">
      <MorningEveningAdhkar />
    </main>
  );
}
