import BeforeSleepMode from "@/components/BeforeSleepMode";

export default function BeforeSleepPage() {
  return (
    <div className="container max-w-4xl pb-20">
      <BeforeSleepMode />
    </div>
  );
}