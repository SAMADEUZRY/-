import FaithJournal from "@/components/FaithJournal";

export default function FaithJournalPage() {
  return (
    <div className="container max-w-4xl pb-20">
      <FaithJournal />
    </div>
  );
}