import { Link } from "wouter";
import { 
  BookOpen, 
  Moon, 
  Clock, 
  ListTodo, 
  MapPin, 
  PenTool, 
  Share2,
  HelpCircle
} from "lucide-react";

export default function MorePage() {
  const features = [
    {
      name: "خطة العبادة الشخصية",
      description: "ضع أهداف عبادة وتتبع تقدمك",
      icon: <ListTodo className="h-6 w-6" />,
      path: "/worship-plan"
    },
    {
      name: "منبه الفجر الذكي",
      description: "لا ينطفئ حتى تقرأ الدعاء",
      icon: <Clock className="h-6 w-6" />,
      path: "/fajr-alarm"
    },
    {
      name: "وضع ما قبل النوم",
      description: "أذكار النوم وتلاوات مهدئة",
      icon: <Moon className="h-6 w-6" />,
      path: "/before-sleep"
    },
    {
      name: "أذكار حسب المكان",
      description: "أذكار المسجد، البيت، السوق والسفر",
      icon: <MapPin className="h-6 w-6" />,
      path: "/location-adhkar"
    },
    {
      name: "المذكرات الإيمانية",
      description: "سجل تجاربك وتأملاتك الروحية",
      icon: <PenTool className="h-6 w-6" />,
      path: "/faith-journal"
    },
    {
      name: "بطاقات الدعاء",
      description: "شارك بطاقات أدعية مع الأحباب",
      icon: <Share2 className="h-6 w-6" />,
      path: "/prayer-cards"
    },
    {
      name: "المساعد الإسلامي",
      description: "أجوبة لأسئلتك الدينية",
      icon: <HelpCircle className="h-6 w-6" />,
      path: "/assistant"
    },
    {
      name: "القرآن الكريم",
      description: "قراءة وتفسير القرآن الكريم",
      icon: <BookOpen className="h-6 w-6" />,
      path: "/quran"
    }
  ];

  return (
    <div className="container max-w-4xl pb-20 p-4">
      <h1 className="text-2xl font-bold text-center mb-6">المزيد من الميزات</h1>
      
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {features.map((feature) => (
          <Link key={feature.path} href={feature.path}>
            <a className="block">
              <div className="bg-card hover:bg-accent transition-colors duration-200 rounded-lg p-4 text-center h-full flex flex-col items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-3">
                  {feature.icon}
                </div>
                <h3 className="font-semibold mb-1">{feature.name}</h3>
                <p className="text-xs text-muted-foreground">{feature.description}</p>
              </div>
            </a>
          </Link>
        ))}
      </div>

      <div className="mt-8 text-center">
        <h2 className="text-xl font-semibold mb-3">قادم قريباً...</h2>
        <div className="flex flex-wrap justify-center gap-2 mt-4">
          <div className="bg-muted px-3 py-1 rounded-full text-sm">الأحاديث النبوية</div>
          <div className="bg-muted px-3 py-1 rounded-full text-sm">مواعظ يومية</div>
          <div className="bg-muted px-3 py-1 rounded-full text-sm">مسابقات إسلامية</div>
          <div className="bg-muted px-3 py-1 rounded-full text-sm">أقرب المساجد</div>
          <div className="bg-muted px-3 py-1 rounded-full text-sm">التقويم الهجري</div>
        </div>
      </div>
    </div>
  );
}