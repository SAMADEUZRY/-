import SmartFajrAlarm from "@/components/SmartFajrAlarm";

export default function FajrAlarmPage() {
  return (
    <div className="container max-w-4xl pb-20">
      <SmartFajrAlarm />
    </div>
  );
}