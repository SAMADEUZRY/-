import PersonalWorshipPlan from "@/components/PersonalWorshipPlan";

export default function WorshipPlanPage() {
  return (
    <div className="container max-w-4xl pb-20">
      <PersonalWorshipPlan />
    </div>
  );
}