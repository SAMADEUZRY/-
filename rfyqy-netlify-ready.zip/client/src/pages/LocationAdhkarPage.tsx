import LocationBasedAdhkar from "@/components/LocationBasedAdhkar";

export default function LocationAdhkarPage() {
  return (
    <div className="container max-w-4xl pb-20">
      <LocationBasedAdhkar />
    </div>
  );
}