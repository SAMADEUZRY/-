import { useTranslation } from "react-i18next";
import QiblaCompass from "@/components/QiblaCompass";

export default function QiblaPage() {
  const { t } = useTranslation();
  
  return (
    <main className="container mx-auto px-4 pb-24">
      <QiblaCompass />
    </main>
  );
}
