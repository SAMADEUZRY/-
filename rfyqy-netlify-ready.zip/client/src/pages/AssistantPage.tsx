import { useTranslation } from "react-i18next";
import IslamicAssistant from "@/components/IslamicAssistant";

export default function AssistantPage() {
  const { t } = useTranslation();
  
  return (
    <main className="container mx-auto px-4 pb-24">
      <IslamicAssistant />
    </main>
  );
}
