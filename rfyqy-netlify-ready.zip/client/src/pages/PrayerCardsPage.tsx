import ShareablePrayerCards from "@/components/ShareablePrayerCards";

export default function PrayerCardsPage() {
  return (
    <div className="container max-w-4xl pb-20">
      <ShareablePrayerCards />
    </div>
  );
}