import { useTranslation } from "react-i18next";
import QuranReader from "@/components/QuranReader";

export default function QuranPage() {
  const { t } = useTranslation();
  
  return (
    <main className="container mx-auto px-4 pb-24">
      <QuranReader />
    </main>
  );
}
