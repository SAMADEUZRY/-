import { useTranslation } from "react-i18next";
import PrayerTimesCard from "@/components/PrayerTimesCard";
import QiblaCompass from "@/components/QiblaCompass";
import DigitalTasbeeh from "@/components/DigitalTasbeeh";
import MorningEveningAdhkar from "@/components/MorningEveningAdhkar";
import QuranReader from "@/components/QuranReader";
import IslamicAssistant from "@/components/IslamicAssistant";

export default function HomePage() {
  const { t } = useTranslation();
  
  return (
    <main className="container mx-auto px-4 pb-24">
      <PrayerTimesCard />
      <QiblaCompass />
      <DigitalTasbeeh />
      <MorningEveningAdhkar />
      <QuranReader />
      <IslamicAssistant />
    </main>
  );
}
