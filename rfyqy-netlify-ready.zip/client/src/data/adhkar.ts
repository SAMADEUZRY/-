export type Dhikr = {
  id: number;
  text: string;
  transliteration?: string;
  translation?: string;
  source?: string;
  repeat: number;
  category: "morning" | "evening" | "both";
};

export const morningAdhkar: Dhikr[] = [
  {
    id: 1,
    text: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
    transliteration: "Asbahna wa asbahal mulku lillahi, wal hamdu lillahi, la ilaha illallahu wahdahu la sharika lahu, lahul mulku wa lahul hamdu, wa huwa 'ala kulli shay'in qadir",
    translation: "We have reached the morning and at this very time unto Allah belongs all sovereignty, and all praise is for Allah. None has the right to be worshipped except Allah, alone, without partner, to Him belongs all sovereignty and praise, and He is over all things omnipotent.",
    source: "رواه مسلم",
    repeat: 1,
    category: "morning"
  },
  {
    id: 2,
    text: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَٰهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
    transliteration: "Allahumma anta rabbi la ilaha illa anta, khalaqtani wa ana abduka, wa ana 'ala ahdika wa wa'dika ma istata'tu, a'udhu bika min sharri ma sana'tu, abu'u laka bini'matika 'alayya, wa abu'u bidhanbi faghfir li fa innahu la yaghfirudh dhunuba illa anta",
    translation: "O Allah, You are my Lord, none has the right to be worshipped except You, You created me and I am Your servant, and I abide to Your covenant and promise as best I can, I take refuge in You from the evil of which I have committed. I acknowledge Your favor upon me and I acknowledge my sin, so forgive me, for verily none can forgive sins except You.",
    source: "رواه البخاري",
    repeat: 1,
    category: "both"
  },
  {
    id: 3,
    text: "سبحان الله وبحمده",
    transliteration: "Subhan-Allahi wa bihamdihi",
    translation: "Glory and praise is to Allah",
    source: "رواه مسلم",
    repeat: 100,
    category: "both"
  },
  {
    id: 4,
    text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي وَدُنْيَايَ وَأَهْلِي وَمَالِي",
    transliteration: "Allahumma inni as'alukal 'afiyah fid dunya wal akhirah. Allahumma inni as'alukal 'afwa wal 'afiyah fi dini wa dunyaya wa ahli wa mali",
    translation: "O Allah, I ask You for well-being in this world and in the Hereafter. O Allah, I ask You for forgiveness and well-being in my religious and my worldly affairs, and my family and my wealth.",
    source: "رواه ابن ماجه",
    repeat: 1,
    category: "both"
  },
  {
    id: 9,
    text: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ الْهَمِّ وَالْحَزَنِ، وَأَعُوذُ بِكَ مِنْ الْعَجْزِ وَالْكَسَلِ، وَأَعُوذُ بِكَ مِنْ الْجُبْنِ وَالْبُخْلِ، وَأَعُوذُ بِكَ مِنْ غَلَبَةِ الدَّيْنِ وَقَهْرِ الرِّجَالِ",
    transliteration: "Allahumma inni a'udhu bika minal-hammi wal-hazan, wa a'udhu bika minal-'ajzi wal-kasal, wa a'udhu bika minal-jubni wal-bukhl, wa a'udhu bika min ghalabatid-dayni wa qahrir-rijal",
    translation: "O Allah, I seek refuge in You from worry and grief, and I seek refuge in You from incapacity and laziness, and I seek refuge in You from cowardice and miserliness, and I seek refuge in You from being overcome by debt and being overpowered by men.",
    source: "رواه البخاري",
    repeat: 1,
    category: "both"
  },
  {
    id: 10,
    text: "اللَّهُمَّ عَالِمَ الْغَيْبِ وَالشَّهَادَةِ، فَاطِرَ السَّمَاوَاتِ وَالْأَرْضِ، رَبَّ كُلِّ شَيْءٍ وَمَلِيكَهُ، أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا أَنْتَ، أَعُوذُ بِكَ مِنْ شَرِّ نَفْسِي وَمِنْ شَرِّ الشَّيْطَانِ وَشِرْكِهِ، وَأَنْ أَقْتَرِفَ عَلَى نَفْسِي سُوءًا، أَوْ أَجُرَّهُ إِلَى مُسْلِمٍ",
    transliteration: "Allahumma 'aalimal-ghaybi wash-shahadah, fatiras-samawati wal-ard, rabba kulli shay'in wa malikah, ashhadu an la ilaha illa ant, a'udhu bika min sharri nafsi wa min sharrish-shaytani wa shirkih, wa an aqtarifa 'ala nafsi su'an aw ajurrahu ila muslim",
    translation: "O Allah, Knower of the unseen and the evident, Maker of the heavens and the earth, Lord of everything and its Master, I bear witness that there is no god but You. I seek refuge in You from the evil of my soul and from the evil of Satan and his polytheism, and from committing wrong against my soul or bringing such upon a Muslim.",
    source: "رواه الترمذي وأبو داود",
    repeat: 1,
    category: "both"
  },
  {
    id: 11,
    text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي وَدُنْيَايَ وَأَهْلِي وَمَالِي، اللَّهُمَّ اسْتُرْ عَوْرَاتِي، وَآمِنْ رَوْعَاتِي، اللَّهُمَّ احْفَظْنِي مِنْ بَيْنِ يَدَيَّ، وَمِنْ خَلْفِي، وَعَنْ يَمِينِي، وَعَنْ شِمَالِي، وَمِنْ فَوْقِي، وَأَعُوذُ بِعَظَمَتِكَ أَنْ أُغْتَالَ مِنْ تَحْتِي",
    transliteration: "Allahumma inni as'alukal-'afwa wal-'afiyah fid-dunya wal-akhirah, Allahumma inni as'alukal-'afwa wal-'afiyah fi dini wa dunyaya wa ahli wa mali, Allahum-mastur 'awrati, wa amin raw'ati, Allahum-mahfazni min bayni yadayya, wa min khalfi, wa 'an yamini, wa 'an shimali, wa min fawqi, wa a'udhu bi-'azamatika an ughtala min tahti",
    translation: "O Allah, I ask You for pardon and well-being in this life and the next. O Allah, I ask You for pardon and well-being in my religious and worldly affairs, and my family and my wealth. O Allah, veil my weaknesses and ease my fear. O Allah, preserve me from the front and from behind, and on my right, and on my left, and from above, and I take refuge in Your greatness from being seized from below.",
    source: "رواه أبو داود وابن ماجه",
    repeat: 1,
    category: "both"
  },
  {
    id: 12,
    text: "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ",
    transliteration: "Allahumma bika asbahna, wa bika amsayna, wa bika nahya, wa bika namut, wa ilaykan-nushur",
    translation: "O Allah, by You we have reached the morning and by You we have reached the evening, by You we live and by You we die, and to You is the resurrection.",
    source: "رواه الترمذي",
    repeat: 1,
    category: "morning"
  },
  {
    id: 13,
    text: "أَصْبَحْنَا عَلَى فِطْرَةِ الْإِسْلَامِ، وَعَلَى كَلِمَةِ الْإِخْلَاصِ، وَعَلَى دِينِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ، وَعَلَى مِلَّةِ أَبِينَا إِبْرَاهِيمَ، حَنِيفًا مُسْلِمًا وَمَا كَانَ مِنَ الْمُشْرِكِينَ",
    transliteration: "Asbahna 'ala fitratil-islam, wa 'ala kalimatil-ikhlas, wa 'ala dini nabiyyina Muhammadin (sallallahu 'alayhi wa sallam), wa 'ala millati abina Ibrahima, hanifan musliman wa ma kana minal-mushrikin",
    translation: "We have reached the morning upon the natural religion of Islam, the word of sincere devotion, the religion of our Prophet Muhammad ﷺ, and the faith of our father Ibrahim. He was upright and a Muslim; he was not from among the polytheists.",
    source: "رواه أحمد",
    repeat: 1,
    category: "morning"
  },
  {
    id: 14,
    text: "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
    transliteration: "La ilaha illallahu wahdahu la sharika lah, lahul-mulku wa lahul-hamd, wa huwa 'ala kulli shay'in qadir",
    translation: "None has the right to be worshipped but Allah alone, Who has no partner. His is the dominion and His is the praise and He is Able to do all things.",
    source: "رواه ابن ماجه",
    repeat: 100,
    category: "both"
  },
  {
    id: 15,
    text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ",
    transliteration: "Subhanallahi wa bihamdihi 'adada khalqih, wa rida nafsih, wa zinata 'arshih, wa midada kalimatih",
    translation: "Glory and praise is to Allah, as many as His creation, as pleases Him, as weighs His throne, and as great as the ink of His words.",
    source: "رواه مسلم",
    repeat: 3,
    category: "morning"
  },
  {
    id: 16,
    text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ",
    transliteration: "Subhanallahi wa bihamdih, subhanallahil-'azim",
    translation: "Glory and praise is to Allah, glory is to Allah the Tremendous.",
    source: "رواه مسلم",
    repeat: 100,
    category: "both"
  },
  {
    id: 17,
    text: "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
    transliteration: "Allahumma salli wa sallim 'ala nabiyyina Muhammad",
    translation: "O Allah, send prayers and peace upon our Prophet Muhammad.",
    source: "رواه الترمذي",
    repeat: 10,
    category: "both"
  },
  {
    id: 18,
    text: "اللَّهُمَّ إِنَّا نَعُوذُ بِكَ مِنْ أَنْ نُشْرِكَ بِكَ شَيْئًا نَعْلَمُهُ، وَنَسْتَغْفِرُكَ لِمَا لَا نَعْلَمُهُ",
    transliteration: "Allahumma inna na'udhu bika min an nushrika bika shay'an na'lamuh, wa nastaghfiruka lima la na'lamuh",
    translation: "O Allah, we seek refuge in You from knowingly associating anything with You, and we seek Your forgiveness for what we do unknowingly.",
    source: "رواه أحمد",
    repeat: 3,
    category: "both"
  }
];

export const eveningAdhkar: Dhikr[] = [
  {
    id: 5,
    text: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
    transliteration: "Amsayna wa amsal mulku lillahi, wal hamdu lillahi, la ilaha illallahu wahdahu la sharika lahu, lahul mulku wa lahul hamdu, wa huwa 'ala kulli shay'in qadir",
    translation: "We have reached the evening and at this very time unto Allah belongs all sovereignty, and all praise is for Allah. None has the right to be worshipped except Allah, alone, without partner, to Him belongs all sovereignty and praise, and He is over all things omnipotent.",
    source: "رواه مسلم",
    repeat: 1,
    category: "evening"
  },
  {
    id: 6,
    text: "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ",
    transliteration: "Allahumma bika amsayna, wa bika asbahna, wa bika nahya, wa bika namutu, wa ilaykal masir",
    translation: "O Allah, by Your leave we have reached the evening and by Your leave we have reached the morning, by Your leave we live and die and unto You is our resurrection.",
    source: "رواه الترمذي",
    repeat: 1,
    category: "evening"
  },
  {
    id: 7,
    text: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
    transliteration: "A'udhu bikalimatillahit-tammati min sharri ma khalaq",
    translation: "I take refuge in the perfect words of Allah from the evil of what He has created.",
    source: "رواه مسلم",
    repeat: 3,
    category: "evening"
  },
  {
    id: 8,
    text: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
    transliteration: "Bismillahil-ladhi la yadurru ma'asmihi shay'un fil-ardi wa la fis-sama'i, wa huwas-sami'ul-'alim",
    translation: "In the name of Allah with whose name nothing is harmed on earth nor in the heavens, and He is the All-Hearing, the All-Knowing.",
    source: "رواه أبو داود والترمذي",
    repeat: 3,
    category: "both"
  },
  {
    id: 19,
    text: "اللَّهُمَّ مَا أَمْسَى بِي مِنْ نِعْمَةٍ أَوْ بِأَحَدٍ مِنْ خَلْقِكَ فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ، فَلَكَ الْحَمْدُ وَلَكَ الشُّكْرُ",
    transliteration: "Allahumma ma amsa bi min ni'matin aw bi'ahadin min khalqika faminaka wahdaka la sharika laka, falakal-hamdu wa lakash-shukr",
    translation: "O Allah, what blessing I or any of Your creation have received in this evening is from You alone, without partner, so for You is all praise and unto You all thanks.",
    source: "رواه أبو داود",
    repeat: 1,
    category: "evening"
  },
  {
    id: 20,
    text: "اللَّهُمَّ إِنِّي أَمْسَيْتُ أُشْهِدُكَ وَأُشْهِدُ حَمَلَةَ عَرْشِكَ، وَمَلَائِكَتَكَ وَجَمِيعَ خَلْقِكَ، أَنَّكَ أَنْتَ اللَّهُ لَا إِلَهَ إِلَّا أَنْتَ وَحْدَكَ لَا شَرِيكَ لَكَ، وَأَنَّ مُحَمَّدًا عَبْدُكَ وَرَسُولُكَ",
    transliteration: "Allahumma inni amsaytu ush-hiduka wa ush-hidu hamalata 'arshika, wa mala'ikataka wa jami'a khalqika, annaka antallahu la ilaha illa anta wahdaka la sharika laka, wa anna Muhammadan 'abduka wa rasuluka",
    translation: "O Allah, I have reached the evening and call on You, the bearers of Your throne, Your angels, and all of Your creation to witness that You are Allah, none has the right to be worshipped except You, alone, without partner and that Muhammad is Your Servant and Messenger.",
    source: "رواه أبو داود",
    repeat: 4,
    category: "evening"
  },
  {
    id: 21,
    text: "أَمْسَيْنَا عَلَى فِطْرَةِ الْإِسْلَامِ، وَعَلَى كَلِمَةِ الْإِخْلَاصِ، وَعَلَى دِينِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ، وَعَلَى مِلَّةِ أَبِينَا إِبْرَاهِيمَ، حَنِيفًا مُسْلِمًا وَمَا كَانَ مِنَ الْمُشْرِكِينَ",
    transliteration: "Amsayna 'ala fitratil-islam, wa 'ala kalimatil-ikhlas, wa 'ala dini nabiyyina Muhammadin (sallallahu 'alayhi wa sallam), wa 'ala millati abina Ibrahima, hanifan musliman wa ma kana minal-mushrikin",
    translation: "We have reached the evening upon the natural religion of Islam, the word of sincere devotion, the religion of our Prophet Muhammad ﷺ, and the faith of our father Ibrahim. He was upright and a Muslim; he was not from among the polytheists.",
    source: "رواه أحمد",
    repeat: 1,
    category: "evening"
  },
  {
    id: 22,
    text: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
    transliteration: "A'udhu bikalimatil-lahit-tammati min sharri ma khalaq",
    translation: "I seek refuge in the perfect words of Allah from the evil of what He has created.",
    source: "رواه مسلم",
    repeat: 3,
    category: "evening"
  },
  {
    id: 23,
    text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ هَذِهِ اللَّيْلَةِ: فَتْحَهَا، وَنَصْرَهَا، وَنُورَهَا، وَبَرَكَتَهَا، وَهُدَاهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِيهَا وَشَرِّ مَا بَعْدَهَا",
    transliteration: "Allahumma inni as'aluka khayra hadhihil-laylati: fat-haha, wa nasraha, wa nuraha, wa barakataha, wa hudaha, wa a'udhu bika min sharri ma fiha wa sharri ma ba'daha",
    translation: "O Allah, I ask You for the good of this night: its victory, its light, its blessing, and its guidance. I seek refuge in You from the evil that is in it and from the evil that follows it.",
    source: "رواه أبو داود",
    repeat: 1,
    category: "evening"
  },
  {
    id: 24,
    text: "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ",
    transliteration: "Allahumma bika amsayna, wa bika asbahna, wa bika nahya, wa bika namut, wa ilaykal-masir",
    translation: "O Allah, by Your leave we have reached the evening and by Your leave we have reached the morning, by Your leave we live and die, and unto You is our return.",
    source: "رواه الترمذي",
    repeat: 1,
    category: "evening"
  },
  {
    id: 25,
    text: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، عَلَيْكَ تَوَكَّلْتُ، وَأَنْتَ رَبُّ الْعَرْشِ الْعَظِيمِ، مَا شَاءَ اللَّهُ كَانَ، وَمَا لَمْ يَشَأْ لَمْ يَكُنْ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ، أَعْلَمُ أَنَّ اللَّهَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، وَأَنَّ اللَّهَ قَدْ أَحَاطَ بِكُلِّ شَيْءٍ عِلْمًا، اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ شَرِّ نَفْسِي، وَمِنْ شَرِّ كُلِّ دَابَّةٍ أَنْتَ آخِذٌ بِنَاصِيَتِهَا، إِنَّ رَبِّي عَلَى صِرَاطٍ مُسْتَقِيمٍ",
    transliteration: "Allahumma anta rabbi la ilaha illa ant, 'alayka tawakkaltu, wa anta rabbul-'arshil-'azim, ma sha Allahu kana, wa ma lam yasha' lam yakun, wa la hawla wa la quwwata illa billahil-'aliyyil-'azim, a'lamu annallaha 'ala kulli shay'in qadir, wa annallaha qad ahata bikulli shay'in 'ilma, Allahumma inni a'udhu bika min sharri nafsi, wa min sharri kulli dabbatin anta akhidhun binasiyatiha, inna rabbi 'ala siratin mustaqim",
    translation: "O Allah, You are my Lord, there is none worthy of worship but You. I place my trust in You and You are Lord of the Mighty Throne. Whatever Allah wills happens, and whatever He does not will, does not happen. There is no might or power except by Allah, the Most High, the Most Great. I know that Allah is capable of all things and that Allah has encompassed all things in knowledge. O Allah, I seek refuge in You from the evil of myself and from the evil of every creature that You hold by its forelock. Surely, my Lord is on the straight path.",
    source: "رواه أبو داود",
    repeat: 1,
    category: "both"
  },
  {
    id: 26,
    text: "حَسْبِيَ اللهُ لا إِلَهَ إِلاَّ هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ",
    transliteration: "Hasbiyallahu la ilaha illa huwa 'alayhi tawakkaltu wa huwa rabbul-'arshil-'azim",
    translation: "Sufficient for me is Allah; there is no deity except Him. On Him I have relied, and He is the Lord of the Great Throne.",
    source: "سورة التوبة: 129",
    repeat: 7,
    category: "both"
  }
];

export const allAdhkar = [...morningAdhkar, ...eveningAdhkar.filter(d => !morningAdhkar.find(m => m.id === d.id))];
