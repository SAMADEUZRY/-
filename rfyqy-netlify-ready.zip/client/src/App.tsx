import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import QuranPage from "@/pages/QuranPage";
import AdhkarPage from "@/pages/AdhkarPage";
import QiblaPage from "@/pages/QiblaPage";
import AssistantPage from "@/pages/AssistantPage";
import MorePage from "@/pages/MorePage";
import WorshipPlanPage from "@/pages/WorshipPlanPage";
import FajrAlarmPage from "@/pages/FajrAlarmPage";
import BeforeSleepPage from "@/pages/BeforeSleepPage";
import LocationAdhkarPage from "@/pages/LocationAdhkarPage";
import FaithJournalPage from "@/pages/FaithJournalPage";
import PrayerCardsPage from "@/pages/PrayerCardsPage";
import AppHeader from "./components/AppHeader";
import BottomNavigation from "./components/BottomNavigation";

function Router() {
  return (
    <>
      <AppHeader />
      <main className="pt-16">
        <Switch>
          {/* Main navigation routes */}
          <Route path="/" component={HomePage} />
          <Route path="/quran" component={QuranPage} />
          <Route path="/adhkar" component={AdhkarPage} />
          <Route path="/qibla" component={QiblaPage} />
          <Route path="/assistant" component={AssistantPage} />
          <Route path="/more" component={MorePage} />
          
          {/* Feature routes */}
          <Route path="/worship-plan" component={WorshipPlanPage} />
          <Route path="/fajr-alarm" component={FajrAlarmPage} />
          <Route path="/before-sleep" component={BeforeSleepPage} />
          <Route path="/location-adhkar" component={LocationAdhkarPage} />
          <Route path="/faith-journal" component={FaithJournalPage} />
          <Route path="/prayer-cards" component={PrayerCardsPage} />
          
          {/* 404 fallback */}
          <Route component={NotFound} />
        </Switch>
      </main>
      <BottomNavigation />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
