import i18n from "i18next";
import { initReactI18next } from "react-i18next";

// Arabic translations
const arTranslations = {
  appName: "رفيقي إلى الله",
  prayer: {
    title: "أوقات الصلاة",
    currentPrayer: "الصلاة الحالية",
    nextPrayer: "الصلاة التالية",
    afterMinutes: "بعد {{minutes}} دقيقة",
    fajr: "الفجر",
    sunrise: "الشروق",
    dhuhr: "الظهر",
    asr: "العصر",
    maghrib: "المغرب",
    isha: "العشاء",
  },
  qibla: {
    title: "اتجاه القبلة",
    direction: "اتجاه القبلة: {{degrees}}° {{direction}}",
    calibrateMessage: "حرك هاتفك ببطء لمعايرة البوصلة",
    north: "شمال",
    south: "جنوب",
    east: "شرق",
    west: "غرب",
    northeast: "شمال شرق",
    northwest: "شمال غرب",
    southeast: "جنوب شرق",
    southwest: "جنوب غرب",
  },
  tasbeeh: {
    title: "المسبحة الإلكترونية",
    increment: "تسبيح",
    reset: "إعادة",
    save: "حفظ",
    completed: "أكملت {{completed}} من {{total}}",
    subhanAllah: "سبحان الله",
    alhamdulillah: "الحمد لله",
    allahuAkbar: "الله أكبر",
    lailahaillallah: "لا إله إلا الله",
  },
  adhkar: {
    title: "أذكار الصباح والمساء",
    morning: "الصباح",
    evening: "المساء",
    progress: "تقدم أذكار {{time}}",
    enableNotifications: "تفعيل تنبيهات الأذكار",
    notificationsDesc: "تذكير تلقائي في أوقات الصباح والمساء",
  },
  quran: {
    title: "القرآن الكريم",
    search: "ابحث في السور...",
    favorites: "المفضلة",
    lastRead: "آخر ما قرأت",
    continueReading: "متابعة القراءة",
    surahs: "السور",
    viewAll: "عرض كل السور",
    ayat: "آيات",
    ayah: "آية",
    juz: "الجزء",
  },
  assistant: {
    title: "المساعد الإسلامي",
    description: "استفسر عن أحكام شرعية أو معلومات إسلامية وسيقوم المساعد الذكي بالإجابة بناءً على مصادر موثوقة.",
    placeholder: "اكتب سؤالك هنا...",
    send: "إرسال",
    suggestedQuestions: "أسئلة مقترحة:",
    greeting: "السلام عليكم! أنا المساعد الإسلامي، كيف يمكنني مساعدتك اليوم؟",
  },
  nav: {
    home: "الرئيسية",
    quran: "القرآن",
    adhkar: "الأذكار",
    qibla: "القبلة",
    assistant: "المساعد",
  },
  general: {
    loading: "جاري التحميل...",
    error: "حدث خطأ",
    retry: "إعادة المحاولة",
  },
};

i18n.use(initReactI18next).init({
  resources: {
    ar: {
      translation: arTranslations,
    },
  },
  lng: "ar",
  fallbackLng: "ar",
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;
